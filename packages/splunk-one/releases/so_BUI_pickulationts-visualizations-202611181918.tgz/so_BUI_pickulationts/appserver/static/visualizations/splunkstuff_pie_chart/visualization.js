/* eslint-disable */
/**
 * Splunk custom visualization: data-team pie / donut inspector.
 * Vanilla AMD for Splunk 9.x custom visualizations.
 */
define(['api/SplunkVisualizationBase'], function (SplunkVisualizationBase) {
    /** Fallback only — runtime NS comes from getPropertyNamespaceInfo() (Splunk 9.4+). */
    var NS = 'display.visualizations.custom.so_BUI_pickulationts.splunkstuff_pie_chart.';
    var VIZ_BUILD = '202611181415-pie-appearance';
    /** Optional text1..text3 strip + info icon — same contract as kpi_line / sparkline. */
    var TEXT_ROW_HEIGHT_PX = 28;
    var TEXT_ROW_SLOTS = 3;
    var INFO_ICON_SIZE_PX = 18;

    // Dashboard Studio default seriesColors (also used by modern Splunk pie).
    var STUDIO_PALETTE = [
        '#7B56DB',
        '#009CEB',
        '#00CDAF',
        '#DD9900',
        '#FF677B',
        '#CB2196',
        '#813193',
        '#0051B5',
        '#008C80',
        '#99B100',
        '#FFA476',
        '#FF6ACE',
        '#AE8CFF',
        '#00689D',
        '#00490A',
        '#465D00',
        '#9D6300',
        '#F6540B',
        '#FF969E',
        '#E47BFE',
    ];
    // Classic Simple XML / older charting defaults.
    var CLASSIC_PALETTE = ['#1E93C6', '#F2B827', '#D6563C', '#6A5C9E', '#31A35F', '#EDA35A', '#CC7B38', '#6DC7B1'];
    var BGDHAMP_PALETTE = [
        '#01417F',
        '#DFA611',
        '#5CC05C',
        '#F47A22',
        '#9B6BFF',
        '#00A9D4',
        '#E85B79',
        '#8B9BB4',
        '#2E8B57',
        '#C44E52',
        '#8172B2',
        '#64B5CD',
    ];

    var DEFAULT_PALETTE = STUDIO_PALETTE;

    var PALETTE_PRESETS = {
        splunk: STUDIO_PALETTE,
        studio: STUDIO_PALETTE,
        classic: CLASSIC_PALETTE,
        bgdhamp: BGDHAMP_PALETTE,
        calm: ['#005F73', '#0A9396', '#94D2BD', '#E9D8A6', '#EE9B00', '#CA6702', '#BB3E03', '#AE2012'],
        bright: ['#0072B2', '#E69F00', '#009E73', '#D55E00', '#CC79A7', '#56B4E9', '#F0E442', '#7A5195'],
        accessible: ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#999999', '#000000'],
        risk: ['#2F80ED', '#27AE60', '#F2C94C', '#F2994A', '#EB5757', '#9B51E0', '#2D9CDB', '#6FCF97'],
    };

    var VALUE_FIELD_HINTS = ['value', 'count', 'sum', 'total', 'amount', 'pct', 'percent', 'avg', 'mean'];
    var LABEL_FIELD_HINTS = ['category', 'label', 'name', 'series', 'slice', 'status', 'host', 'field'];
    var COMPARE_FIELD_HINTS = ['previous', 'prior', 'baseline', 'compare', 'target', 'last', 'prev'];
    var COLOR_FIELD_HINTS = ['color', 'colour', 'hex', 'fill'];
    var SKIP_FIELD_NAMES = {
        _time: true,
        _span: true,
        _spandays: true,
        punct: true,
        text1: true,
        text2: true,
        text3: true,
        info: true,
    };

    function fieldsList(rawData) {
        if (rawData && rawData.fields && rawData.fields.length) {
            return rawData.fields;
        }
        if (rawData && rawData.meta && rawData.meta.fields && rawData.meta.fields.length) {
            return rawData.meta.fields;
        }
        return [];
    }

    function cellValue(cell) {
        if (cell == null) {
            return cell;
        }
        if (typeof cell === 'object' && cell.value != null) {
            return cell.value;
        }
        return cell;
    }

    function fieldName(fields, idx) {
        var f = fields && fields[idx];
        if (typeof f === 'string') {
            return f;
        }
        if (f && f.name != null) {
            return String(f.name);
        }
        return '';
    }

    function normalizeName(name) {
        return String(name == null ? '' : name)
            .trim()
            .toLowerCase();
    }

    function normalizeFieldName(fields, idx) {
        return normalizeName(fieldName(fields, idx));
    }

    function isSkippedFieldName(name) {
        var n = normalizeName(name);
        if (SKIP_FIELD_NAMES[n] === true || n.indexOf('_time') === 0) {
            return true;
        }
        if (/^text[123]$/.test(n) || /^text[123]_/.test(n) || /^urls?\d*$/.test(n)) {
            return true;
        }
        return false;
    }

    /** Splunk dashboard wrappers often set pointer-events:none on viz hosts; don't stop early. */
    function enableAncestorPointerEvents(el, maxDepth) {
        var node = el;
        var depth = 0;
        var limit = maxDepth == null ? 24 : maxDepth;
        while (node && depth < limit) {
            if (node.style) {
                node.style.pointerEvents = 'auto';
            }
            node = node.parentElement;
            depth += 1;
        }
    }

    function cellText(cell) {
        var v = cellValue(cell);
        return v == null ? '' : String(v).trim();
    }

    /** All columns keyed by field name; last row is “latest” for text/info (same as line). */
    function collectStringFields(rawData) {
        var out = {};
        var fields = fieldsList(rawData);
        var c;
        if (!rawData || !rawData.columns) {
            return out;
        }
        for (c = 0; c < rawData.columns.length; c += 1) {
            var name = fieldName(fields, c);
            if (!name) {
                continue;
            }
            var col = rawData.columns[c] || [];
            out[name] = col.map(function (cell) {
                return cellText(cell);
            });
        }
        return out;
    }

    function lastStringValue(stringFields, field) {
        var name = String(field == null ? '' : field).trim();
        if (!name || !stringFields) {
            return '';
        }
        var col = stringFields[name];
        if (!col || !col.length) {
            return '';
        }
        var i;
        for (i = col.length - 1; i >= 0; i -= 1) {
            if (col[i]) {
                return String(col[i]).trim();
            }
        }
        return '';
    }

    function fillTemplate(template, value, label) {
        return String(template)
            .split('$value$')
            .join(value)
            .split('$label$')
            .join(label);
    }

    function escapeSplValue(v) {
        return String(v == null ? '' : v)
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"');
    }

    function splunkPathPrefix(ownerDoc) {
        var win = ownerDoc && ownerDoc.defaultView;
        var p = win && win.location ? String(win.location.pathname || '') : '';
        var idx = p.indexOf('/app/');
        return idx > 0 ? p.slice(0, idx) : '';
    }

    function withSplunkPrefix(url, prefix) {
        if (!prefix) {
            return url;
        }
        if (url.indexOf('/app/') === 0 || url.indexOf('/manager/') === 0) {
            return prefix + url;
        }
        return url;
    }

    function isSafeUrlTemplate(template) {
        var t = String(template == null ? '' : template).trim();
        return /^https?:\/\//i.test(t) || /^\/(?![\/\\])/.test(t);
    }

    function buildUrlLink(template, value, label, prefix) {
        var t = String(template == null ? '' : template).trim();
        if (!t || !isSafeUrlTemplate(t)) {
            return '';
        }
        var url = fillTemplate(
            t,
            encodeURIComponent(value == null ? '' : value),
            encodeURIComponent(label == null ? '' : label)
        );
        return withSplunkPrefix(url, prefix || '');
    }

    function buildSearchLink(template, value, label, earliest, latest, prefix) {
        var t = String(template == null ? '' : template).trim();
        if (!t) {
            return '';
        }
        var spl = fillTemplate(t, escapeSplValue(value), escapeSplValue(label));
        var url = '/app/search/search?q=' + encodeURIComponent(spl);
        var e = String(earliest == null ? '' : earliest).trim();
        var l = String(latest == null ? '' : latest).trim();
        if (e) {
            url += '&earliest=' + encodeURIComponent(e);
        }
        if (l) {
            url += '&latest=' + encodeURIComponent(l);
        }
        return withSplunkPrefix(url, prefix || '');
    }

    function cellLabel(stringFields, labelField, fallbackLabel) {
        var fromField = lastStringValue(stringFields, labelField);
        if (fromField) {
            return fromField;
        }
        return String(fallbackLabel == null ? '' : fallbackLabel);
    }

    function cellUrl(urlTpl, urlFromField, value, label, prefix) {
        return (
            buildUrlLink(urlTpl, value, label, prefix) ||
            buildUrlLink(urlFromField, value, label, prefix)
        );
    }

    function collectTextCells(stringFields, config) {
        var cells = [];
        var i;
        if (!readBool(config, 'showTextRow', true)) {
            return cells;
        }
        for (i = 1; i <= TEXT_ROW_SLOTS; i += 1) {
            var field = String(readConfig(config, 'text' + i + 'Field', 'text' + i) || '').trim();
            var value = lastStringValue(stringFields, field);
            if (!value) {
                continue;
            }
            var labelField = String(readConfig(config, 'text' + i + 'LabelField', '') || '').trim();
            var urlField = String(readConfig(config, 'text' + i + 'LinkUrlField', '') || '').trim();
            cells.push({
                slot: i,
                label: cellLabel(
                    stringFields,
                    labelField,
                    String(readConfig(config, 'text' + i + 'Label', 'Text' + i) || '')
                ),
                value: value,
                urlTpl: String(readConfig(config, 'text' + i + 'LinkUrl', '') || ''),
                urlFromField: lastStringValue(stringFields, urlField),
                searchTpl: String(readConfig(config, 'text' + i + 'LinkSearch', '') || ''),
            });
        }
        return cells;
    }

    function styleTextCell(el, isFirst) {
        el.className = 'bgdhamp-pie-chart-viz__textCell';
        el.style.setProperty('flex', '1 1 0', 'important');
        el.style.setProperty('width', 'auto', 'important');
        el.style.setProperty('min-width', '0', 'important');
        el.style.display = 'block';
        el.style.boxSizing = 'border-box';
        el.style.padding = '0 8px';
        el.style.lineHeight = TEXT_ROW_HEIGHT_PX + 'px';
        el.style.whiteSpace = 'nowrap';
        el.style.overflow = 'hidden';
        el.style.textOverflow = 'ellipsis';
        el.style.textAlign = 'center';
        el.style.fontSize = '12px';
        el.style.fontWeight = '500';
        if (!isFirst) {
            el.style.borderLeft = '1px solid rgba(0,0,0,0.18)';
        }
    }

    function makeLinkCell(ownerDoc, href, target) {
        var a = ownerDoc.createElement('a');
        a.setAttribute('href', href);
        a.setAttribute('target', target);
        a.setAttribute('rel', 'noopener noreferrer');
        a.style.setProperty('color', 'inherit', 'important');
        a.style.setProperty('text-decoration', 'none', 'important');
        a.style.cursor = 'pointer';
        a.addEventListener('mouseenter', function () {
            a.style.setProperty('text-decoration', 'underline', 'important');
        });
        a.addEventListener('mouseleave', function () {
            if (ownerDoc.activeElement !== a) {
                a.style.setProperty('text-decoration', 'none', 'important');
            }
        });
        a.addEventListener('focus', function () {
            a.style.setProperty('text-decoration', 'underline', 'important');
            a.style.outline = '2px solid currentColor';
            a.style.outlineOffset = '-2px';
        });
        a.addEventListener('blur', function () {
            a.style.setProperty('text-decoration', 'none', 'important');
            a.style.outline = 'none';
        });
        return a;
    }

    var infoPopoverSeq = 0;

    function mountInfoPopover(viz, root, ownerDoc, text, topPx) {
        var btn = ownerDoc.createElement('button');
        btn.type = 'button';
        btn.className = 'bgdhamp-pie-chart-viz__info';
        btn.setAttribute('aria-label', 'More information');
        btn.setAttribute('aria-expanded', 'false');
        btn.textContent = 'i';
        btn.style.position = 'absolute';
        btn.style.top = topPx + 'px';
        btn.style.right = '8px';
        btn.style.zIndex = '7';
        btn.style.width = INFO_ICON_SIZE_PX + 'px';
        btn.style.height = INFO_ICON_SIZE_PX + 'px';
        btn.style.padding = '0';
        btn.style.margin = '0';
        btn.style.border = '1.5px solid currentColor';
        btn.style.borderRadius = '50%';
        btn.style.background = 'rgba(0,0,0,0.08)';
        btn.style.color = 'inherit';
        btn.style.font = 'italic 700 11px/1 Georgia, "Times New Roman", serif';
        btn.style.cursor = 'pointer';
        btn.style.display = 'flex';
        btn.style.alignItems = 'center';
        btn.style.justifyContent = 'center';
        btn.style.boxSizing = 'border-box';

        infoPopoverSeq += 1;
        var pop = ownerDoc.createElement('div');
        pop.id = 'bgdhamp-pie-info-' + infoPopoverSeq;
        pop.className = 'bgdhamp-pie-chart-viz__infoPopover';
        pop.setAttribute('role', 'tooltip');
        pop.textContent = text;
        pop.style.display = 'none';
        pop.style.position = 'fixed';
        pop.style.zIndex = '2147483646';
        pop.style.maxWidth = '280px';
        pop.style.padding = '8px 10px';
        pop.style.fontSize = '12px';
        pop.style.lineHeight = '1.4';
        pop.style.color = '#FFFFFF';
        pop.style.background = 'rgba(11,31,59,0.96)';
        pop.style.border = '1px solid rgba(255,255,255,0.25)';
        pop.style.borderRadius = '4px';
        pop.style.boxShadow = '0 2px 8px rgba(0,0,0,0.35)';
        pop.style.whiteSpace = 'pre-wrap';
        btn.setAttribute('aria-describedby', pop.id);

        var pinned = false;

        function place() {
            var rect = btn.getBoundingClientRect();
            var win = ownerDoc.defaultView || window;
            var vw = win.innerWidth || ownerDoc.documentElement.clientWidth || 0;
            pop.style.top = Math.round(rect.bottom + 6) + 'px';
            pop.style.right = Math.max(4, Math.round(vw - rect.right)) + 'px';
        }

        function show() {
            var bodyEl = ownerDoc.body || ownerDoc.documentElement;
            if (bodyEl && pop.parentNode !== bodyEl) {
                bodyEl.appendChild(pop);
            }
            place();
            pop.style.display = 'block';
            btn.setAttribute('aria-expanded', 'true');
            viz._infoOpen = true;
        }

        function hide() {
            pop.style.display = 'none';
            btn.setAttribute('aria-expanded', 'false');
            viz._infoOpen = false;
        }

        btn.addEventListener('mouseenter', show);
        btn.addEventListener('focus', show);
        btn.addEventListener('mouseleave', function () {
            if (!pinned) {
                hide();
            }
        });
        btn.addEventListener('blur', function () {
            if (!pinned) {
                hide();
            }
        });
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            pinned = !pinned;
            if (pinned) {
                show();
            } else {
                hide();
            }
        });

        function onDocClick(e) {
            if (!pinned) {
                return;
            }
            var t = e.target;
            if (t === btn || btn.contains(t) || t === pop || pop.contains(t)) {
                return;
            }
            pinned = false;
            hide();
        }

        function onKey(e) {
            if (e.key === 'Escape' || e.key === 'Esc') {
                if (pop.style.display !== 'none') {
                    pinned = false;
                    hide();
                }
            }
        }

        ownerDoc.addEventListener('click', onDocClick, true);
        ownerDoc.addEventListener('keydown', onKey, true);
        root.appendChild(btn);

        return function teardownInfo() {
            ownerDoc.removeEventListener('click', onDocClick, true);
            ownerDoc.removeEventListener('keydown', onKey, true);
            if (pop.parentNode) {
                pop.parentNode.removeChild(pop);
            }
            viz._infoOpen = false;
        };
    }

    function propertyNamespace(viz) {
        if (viz && typeof viz.getPropertyNamespaceInfo === 'function') {
            try {
                var info = viz.getPropertyNamespaceInfo();
                if (info && info.propertyNamespace) {
                    var ns = String(info.propertyNamespace);
                    return ns.charAt(ns.length - 1) === '.' ? ns : ns + '.';
                }
            } catch (ignoreErr) {
                /* SplunkVisualizationBase may not expose namespace in all contexts */
            }
        }
        return NS;
    }

    /**
     * Splunk 9.4.x Format keys use the installed app id in the namespace.
     * Also accept bare prop / suffix matches so Appearance/Data still apply after transfer.
     */
    function findConfigValue(config, prop, viz) {
        if (config == null || typeof config !== 'object') {
            return { found: false, value: undefined };
        }
        var ns = propertyNamespace(viz || readConfig._activeViz);
        var candidates = [ns + prop, NS + prop, prop];
        var ci;
        for (ci = 0; ci < candidates.length; ci += 1) {
            var v = config[candidates[ci]];
            if (v !== undefined && v !== null) {
                return { found: true, value: v };
            }
        }
        var suffix = '.' + prop;
        var keys = Object.keys(config);
        var ki;
        for (ki = 0; ki < keys.length; ki += 1) {
            var key = keys[ki];
            if (key.length >= suffix.length && key.slice(-suffix.length) === suffix) {
                var v2 = config[key];
                if (v2 !== undefined && v2 !== null) {
                    return { found: true, value: v2 };
                }
            }
        }
        return { found: false, value: undefined };
    }

    function readConfig(config, prop, fallback) {
        var found = findConfigValue(config, prop, readConfig._activeViz);
        if (!found.found || found.value === '') {
            return fallback;
        }
        return found.value;
    }

    function readString(config, prop, fallback) {
        return String(readConfig(config, prop, fallback) || '').trim();
    }

    function readFieldChoice(config, prop, fallback) {
        var choice = readString(config, prop, fallback);
        var normalized = normalizeName(choice);
        return normalized === 'auto' || normalized === 'none' ? '' : choice;
    }

    function readBool(config, prop, fallback) {
        var raw = readConfig(config, prop, fallback ? 'true' : 'false');
        var s = String(raw == null ? '' : raw).trim().toLowerCase();
        if (s === '1' || s === 'true' || s === 'yes' || s === 'on') {
            return true;
        }
        if (s === '0' || s === 'false' || s === 'no' || s === 'off') {
            return false;
        }
        return !!fallback;
    }

    function readNumber(config, prop, fallback, min, max) {
        var raw = readConfig(config, prop, fallback);
        var n = parseFloat(String(raw == null ? '' : raw).replace(/,/g, '').trim(), 10);
        if (!isFinite(n)) {
            n = fallback;
        }
        if (isFinite(min) && n < min) {
            n = min;
        }
        if (isFinite(max) && n > max) {
            n = max;
        }
        return n;
    }

    function safeColor(raw, fallback) {
        var s = String(raw == null ? '' : raw).trim();
        if (!s) {
            return fallback;
        }
        if (s.toLowerCase() === 'transparent') {
            return 'transparent';
        }
        if (/^[0-9A-Fa-f]{6}$/.test(s) || /^[0-9A-Fa-f]{3}$/.test(s)) {
            s = '#' + s;
        }
        if (/^#[0-9A-Fa-f]{6}$/.test(s)) {
            return s;
        }
        if (/^#[0-9A-Fa-f]{3}$/.test(s)) {
            return (
                '#' +
                s.charAt(1) +
                s.charAt(1) +
                s.charAt(2) +
                s.charAt(2) +
                s.charAt(3) +
                s.charAt(3)
            );
        }
        if (/^rgba?\(\s*[\d.]+\s*,/.test(s)) {
            return s;
        }
        return fallback;
    }

    function parseNum(cell) {
        if (typeof cell === 'number' && isFinite(cell)) {
            return cell;
        }
        var raw = cellValue(cell);
        if (raw == null || raw === '') {
            return NaN;
        }
        if (typeof raw === 'number' && isFinite(raw)) {
            return raw;
        }
        var s = String(raw).replace(/,/g, '').replace(/%$/, '').trim();
        var n = parseFloat(s, 10);
        return isFinite(n) ? n : NaN;
    }

    function isNumericColumn(rawData, colIdx) {
        var col = (rawData.columns && rawData.columns[colIdx]) || [];
        var r;
        for (r = 0; r < col.length; r += 1) {
            if (isFinite(parseNum(col[r]))) {
                return true;
            }
        }
        return false;
    }

    function fieldHintScore(name, hints) {
        var i;
        for (i = 0; i < hints.length; i += 1) {
            if (name === hints[i] || name.indexOf(hints[i]) >= 0) {
                return true;
            }
        }
        return false;
    }

    function findFieldIndex(fields, requested) {
        var wanted = normalizeName(requested);
        var i;
        if (!wanted) {
            return -1;
        }
        for (i = 0; i < fields.length; i += 1) {
            if (normalizeName(fieldName(fields, i)) === wanted) {
                return i;
            }
        }
        return -1;
    }

    function paletteForPreset(raw) {
        var key = normalizeName(raw || 'splunk');
        return (PALETTE_PRESETS[key] || DEFAULT_PALETTE).slice();
    }

    function parsePalette(raw, preset) {
        var source = String(raw || '').trim();
        var colors = [];
        var parts;
        var i;
        if (!source) {
            return paletteForPreset(preset);
        }
        parts = source.split(/[,\s]+/);
        for (i = 0; i < parts.length; i += 1) {
            var c = safeColor(parts[i], '');
            if (c) {
                colors.push(c);
            }
        }
        return colors.length ? colors : paletteForPreset(preset);
    }

    function parseColorMap(raw) {
        var source = String(raw || '').trim();
        var out = {};
        var parsed;
        var pairs;
        var i;
        if (!source) {
            return out;
        }
        if (source.charAt(0) === '{') {
            try {
                parsed = JSON.parse(source);
                Object.keys(parsed || {}).forEach(function (key) {
                    var color = safeColor(parsed[key], '');
                    if (color) {
                        out[String(key)] = color;
                    }
                });
                return out;
            } catch (ignore) {
                return out;
            }
        }
        pairs = source.split(/[,\n]+/);
        for (i = 0; i < pairs.length; i += 1) {
            var pair = pairs[i].split('=');
            if (pair.length >= 2) {
                var label = pair.shift().trim();
                var mappedColor = safeColor(pair.join('=').trim(), '');
                if (label && mappedColor) {
                    out[label] = mappedColor;
                }
            }
        }
        return out;
    }

    function readOptions(config) {
        var palettePreset = readString(config, 'palettePreset', 'studio') || 'studio';
        var labelCustom = readString(config, 'labelFieldCustom', '');
        var valueCustom = readString(config, 'valueFieldCustom', '');
        var compareCustom = readString(config, 'compareFieldCustom', '');
        var colorCustom = readString(config, 'colorFieldCustom', '');
        return {
            labelField: labelCustom || readFieldChoice(config, 'labelField', ''),
            valueField: valueCustom || readFieldChoice(config, 'valueField', ''),
            compareField: compareCustom || readFieldChoice(config, 'compareField', ''),
            colorField: colorCustom || readFieldChoice(config, 'colorField', ''),
            topN: Math.floor(readNumber(config, 'topN', 5, 0, 1000)),
            otherEnabled: readBool(config, 'otherEnabled', true),
            otherLabel: readString(config, 'otherLabel', 'Other') || 'Other',
            /** Classic pie “minimum size” — collapse slices below this percent into Other. */
            minSlicePercent: readNumber(config, 'minSlicePercent', 1, 0, 100),
            minSliceValue: readNumber(config, 'minSliceValue', 0, 0, Number.POSITIVE_INFINITY),
            sortMode: readString(config, 'sortMode', 'value-desc') || 'value-desc',
            showPercent: readBool(config, 'showPercent', true),
            showValue: readBool(config, 'showValue', false),
            showRowCount: readBool(config, 'showRowCount', false),
            showCompare: readBool(config, 'showCompare', false),
            showDataQuality: readBool(config, 'showDataQuality', false),
            showTooltip: readBool(config, 'showTooltip', true),
            showInspector: readBool(config, 'showInspector', false),
            showOtherBreakdown: readBool(config, 'showOtherBreakdown', true),
            /** Studio default: labels around the pie (legend off). */
            showSliceLabels: readBool(config, 'showSliceLabels', true),
            sliceLabelMinPercent: readNumber(config, 'sliceLabelMinPercent', 0, 0, 100),
            title: String(readConfig(config, 'title', '') || ''),
            emptyMessage: readString(config, 'emptyMessage', 'No data to display.') || 'No data to display.',
            background: safeColor(readConfig(config, 'background', '#01417F'), '#01417F'),
            textColor: safeColor(readConfig(config, 'textColor', '#FFFFFF'), '#FFFFFF'),
            textRowBackground: safeColor(
                readConfig(config, 'textRowBackground', 'rgba(0,0,0,0.35)'),
                'rgba(0,0,0,0.35)'
            ),
            palettePreset: palettePreset,
            palette: parsePalette(readConfig(config, 'palette', ''), palettePreset),
            colorMap: parseColorMap(readConfig(config, 'colorMap', '')),
            otherColor: safeColor(readConfig(config, 'otherColor', '#8B9BB4'), '#8B9BB4'),
            /** 0 = solid Classic / Studio pie; Format can still enable a donut hole. */
            innerRadius: readNumber(config, 'innerRadius', 0, 0, 82),
            legendPosition: readString(config, 'legendPosition', 'none') || 'none',
            drilldown: readBool(config, 'drilldown', false),
            drilldownAction: readString(config, 'drilldownAction', 'tokens') || 'tokens',
            drilldownQuery:
                readString(
                    config,
                    'drilldownQuery',
                    'search $pie_filter_clause$ | stats count by $pie_label_field$'
                ) || 'search $pie_filter_clause$ | stats count',
            tokenPrefix: readString(config, 'tokenPrefix', 'pie') || 'pie',
        };
    }

    function pickColumns(rawData, opts, quality) {
        var fields = fieldsList(rawData);
        var valueIdx = findFieldIndex(fields, opts.valueField);
        var labelIdx = findFieldIndex(fields, opts.labelField);
        var compareIdx = findFieldIndex(fields, opts.compareField);
        var colorIdx = findFieldIndex(fields, opts.colorField);
        var c;
        var name;

        if (opts.valueField && valueIdx < 0) {
            quality.missingFields.push('valueField=' + opts.valueField);
        }
        if (opts.labelField && labelIdx < 0) {
            quality.missingFields.push('labelField=' + opts.labelField);
        }
        if (opts.compareField && compareIdx < 0) {
            quality.missingFields.push('compareField=' + opts.compareField);
        }
        if (opts.colorField && colorIdx < 0) {
            quality.missingFields.push('colorField=' + opts.colorField);
        }

        if (valueIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                name = normalizeFieldName(fields, c);
                if (isSkippedFieldName(name)) {
                    continue;
                }
                if (fieldHintScore(name, VALUE_FIELD_HINTS) && isNumericColumn(rawData, c)) {
                    valueIdx = c;
                    break;
                }
            }
        }
        if (valueIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                name = normalizeFieldName(fields, c);
                if (!isSkippedFieldName(name) && isNumericColumn(rawData, c)) {
                    valueIdx = c;
                    break;
                }
            }
        }

        if (labelIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                if (c === valueIdx) {
                    continue;
                }
                name = normalizeFieldName(fields, c);
                if (isSkippedFieldName(name)) {
                    continue;
                }
                if (fieldHintScore(name, LABEL_FIELD_HINTS) && !isNumericColumn(rawData, c)) {
                    labelIdx = c;
                    break;
                }
            }
        }
        if (labelIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                if (c === valueIdx) {
                    continue;
                }
                name = normalizeFieldName(fields, c);
                if (!isSkippedFieldName(name) && !isNumericColumn(rawData, c)) {
                    labelIdx = c;
                    break;
                }
            }
        }

        if (!opts.compareField && compareIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                if (c === valueIdx || c === labelIdx) {
                    continue;
                }
                name = normalizeFieldName(fields, c);
                if (fieldHintScore(name, COMPARE_FIELD_HINTS) && isNumericColumn(rawData, c)) {
                    compareIdx = c;
                    break;
                }
            }
        }
        if (!opts.colorField && colorIdx < 0) {
            for (c = 0; c < rawData.columns.length; c += 1) {
                if (c === valueIdx || c === labelIdx || c === compareIdx) {
                    continue;
                }
                name = normalizeFieldName(fields, c);
                if (fieldHintScore(name, COLOR_FIELD_HINTS)) {
                    colorIdx = c;
                    break;
                }
            }
        }

        return {
            labelIdx: labelIdx,
            valueIdx: valueIdx,
            compareIdx: compareIdx,
            colorIdx: colorIdx,
            labelFieldName: labelIdx >= 0 ? fieldName(fields, labelIdx) : '',
            valueFieldName: valueIdx >= 0 ? fieldName(fields, valueIdx) : '',
            compareFieldName: compareIdx >= 0 ? fieldName(fields, compareIdx) : '',
            colorFieldName: colorIdx >= 0 ? fieldName(fields, colorIdx) : '',
        };
    }

    function blankQuality() {
        return {
            rowCount: 0,
            usedRows: 0,
            droppedNonNumeric: 0,
            droppedNegative: 0,
            zeroRows: 0,
            blankLabels: 0,
            compareMissing: 0,
            colorInvalid: 0,
            missingFields: [],
            groupedSlices: 0,
            groupedRows: 0,
        };
    }

    function buildSlices(rawData, opts) {
        var quality = blankQuality();
        var fields = fieldsList(rawData);
        var picked = pickColumns(rawData, opts, quality);
        var byLabel = {};
        var order = [];
        var labelCol;
        var valueCol;
        var compareCol;
        var colorCol;
        var rowCount;
        var r;

        if (!rawData || !rawData.columns || rawData.columns.length === 0 || picked.valueIdx < 0) {
            return {
                slices: [],
                fields: fields,
                picked: picked,
                quality: quality,
                error: 'Pie chart needs a numeric value column. Use valueField to choose one explicitly.',
            };
        }

        labelCol = picked.labelIdx >= 0 ? rawData.columns[picked.labelIdx] || [] : [];
        valueCol = rawData.columns[picked.valueIdx] || [];
        compareCol = picked.compareIdx >= 0 ? rawData.columns[picked.compareIdx] || [] : [];
        colorCol = picked.colorIdx >= 0 ? rawData.columns[picked.colorIdx] || [] : [];
        rowCount = valueCol.length;
        if (picked.labelIdx >= 0) {
            rowCount = Math.max(rowCount, labelCol.length);
        }
        quality.rowCount = rowCount;

        for (r = 0; r < rowCount; r += 1) {
            var val = parseNum(valueCol[r]);
            var rawLabel;
            var label;
            var compareVal;
            var color;
            if (!isFinite(val)) {
                quality.droppedNonNumeric += 1;
                continue;
            }
            if (val < 0) {
                quality.droppedNegative += 1;
                continue;
            }
            if (val === 0) {
                quality.zeroRows += 1;
            }
            rawLabel = picked.labelIdx >= 0 ? cellValue(labelCol[r]) : null;
            label = picked.labelIdx >= 0 ? String(rawLabel == null ? '' : rawLabel) : 'Row ' + (r + 1);
            if (!label) {
                label = '(blank)';
                quality.blankLabels += 1;
            }
            if (!Object.prototype.hasOwnProperty.call(byLabel, label)) {
                byLabel[label] = {
                    label: label,
                    value: 0,
                    compareValue: null,
                    rowCount: 0,
                    inputOrder: order.length,
                    color: '',
                };
                order.push(label);
            }
            byLabel[label].value += val;
            byLabel[label].rowCount += 1;
            quality.usedRows += 1;

            if (picked.compareIdx >= 0) {
                compareVal = parseNum(compareCol[r]);
                if (isFinite(compareVal)) {
                    if (byLabel[label].compareValue === null) {
                        byLabel[label].compareValue = 0;
                    }
                    byLabel[label].compareValue += compareVal;
                } else {
                    quality.compareMissing += 1;
                }
            }

            if (picked.colorIdx >= 0 && !byLabel[label].color) {
                color = safeColor(cellValue(colorCol[r]), '');
                if (color) {
                    byLabel[label].color = color;
                } else if (cellValue(colorCol[r])) {
                    quality.colorInvalid += 1;
                }
            }
        }

        return {
            slices: order.map(function (key) {
                return byLabel[key];
            }),
            fields: fields,
            picked: picked,
            quality: quality,
            error: '',
        };
    }

    function sortSlices(slices, sortMode) {
        var mode = String(sortMode || 'value-desc').toLowerCase();
        return slices.slice().sort(function (a, b) {
            if (mode === 'label-asc') {
                return String(a.label).localeCompare(String(b.label));
            }
            if (mode === 'label-desc') {
                return String(b.label).localeCompare(String(a.label));
            }
            if (mode === 'value-asc') {
                return a.value - b.value || a.inputOrder - b.inputOrder;
            }
            if (mode === 'input') {
                return a.inputOrder - b.inputOrder;
            }
            return b.value - a.value || a.inputOrder - b.inputOrder;
        });
    }

    function sumMembers(members, prop) {
        var total = 0;
        var i;
        for (i = 0; i < members.length; i += 1) {
            total += members[i][prop] || 0;
        }
        return total;
    }

    function shapeSlices(slices, opts, quality) {
        var positive = slices.filter(function (s) {
            return s.value > 0;
        });
        var ranked = sortSlices(positive, 'value-desc');
        var total = sumMembers(positive, 'value');
        var rankMap = {};
        var sorted = sortSlices(positive, opts.sortMode);
        var keep = [];
        var grouped = [];
        var i;

        for (i = 0; i < ranked.length; i += 1) {
            rankMap[ranked[i].label] = i + 1;
        }

        for (i = 0; i < sorted.length; i += 1) {
            var s = sorted[i];
            var percent = total > 0 ? (s.value / total) * 100 : 0;
            var shouldGroup =
                opts.otherEnabled &&
                ((opts.topN > 0 && keep.length >= opts.topN) ||
                    (opts.minSliceValue > 0 && s.value < opts.minSliceValue) ||
                    (opts.minSlicePercent > 0 && percent < opts.minSlicePercent));
            if (shouldGroup) {
                grouped.push(s);
            } else {
                keep.push(s);
            }
        }

        if (opts.otherEnabled && grouped.length) {
            keep.push({
                label: opts.otherLabel,
                value: sumMembers(grouped, 'value'),
                compareValue: grouped.some(function (s) { return s.compareValue !== null; })
                    ? sumMembers(grouped, 'compareValue')
                    : null,
                rowCount: sumMembers(grouped, 'rowCount'),
                inputOrder: Number.MAX_SAFE_INTEGER || 9007199254740991,
                color: opts.otherColor,
                isOther: true,
                members: sortSlices(grouped, 'value-desc'),
            });
            quality.groupedSlices = grouped.length;
            quality.groupedRows = sumMembers(grouped, 'rowCount');
        }

        for (i = 0; i < keep.length; i += 1) {
            keep[i].rank = keep[i].isOther ? null : rankMap[keep[i].label];
            keep[i].percent = total > 0 ? (keep[i].value / total) * 100 : 0;
            keep[i].color = chooseColor(keep[i], i, opts);
        }

        return {
            slices: keep,
            total: total,
            originalSliceCount: positive.length,
        };
    }

    function chooseColor(slice, idx, opts) {
        if (slice.isOther) {
            return opts.otherColor;
        }
        if (slice.color) {
            return slice.color;
        }
        if (opts.colorMap && opts.colorMap[slice.label]) {
            return opts.colorMap[slice.label];
        }
        return opts.palette[idx % opts.palette.length];
    }

    function pctText(value, precision) {
        return (isFinite(value) ? value : 0).toFixed(precision == null ? 1 : precision) + '%';
    }

    function valueText(value) {
        return Number(value || 0).toLocaleString();
    }

    function compareText(slice) {
        if (slice.compareValue === null || !isFinite(slice.compareValue)) {
            return '';
        }
        var delta = slice.value - slice.compareValue;
        var pct = slice.compareValue === 0 ? null : (delta / Math.abs(slice.compareValue)) * 100;
        var sign = delta > 0 ? '+' : '';
        return sign + valueText(delta) + (pct === null ? '' : ' (' + sign + pctText(pct, 1) + ')');
    }

    function qualityMessages(model) {
        var q = model.quality;
        var msgs = [];
        if (q.missingFields.length) {
            msgs.push('Missing configured fields: ' + q.missingFields.join(', '));
        }
        if (q.droppedNonNumeric) {
            msgs.push(q.droppedNonNumeric + ' rows ignored with non-numeric values');
        }
        if (q.droppedNegative) {
            msgs.push(q.droppedNegative + ' negative rows ignored');
        }
        if (q.blankLabels) {
            msgs.push(q.blankLabels + ' blank labels grouped as (blank)');
        }
        if (q.zeroRows) {
            msgs.push(q.zeroRows + ' zero-value rows kept out of the visible area');
        }
        if (q.compareMissing) {
            msgs.push(q.compareMissing + ' rows missing compare values');
        }
        if (q.colorInvalid) {
            msgs.push(q.colorInvalid + ' invalid color values ignored');
        }
        if (q.groupedSlices) {
            msgs.push(q.groupedSlices + ' slices / ' + q.groupedRows + ' rows grouped into Other');
        }
        if (!msgs.length && q.rowCount) {
            msgs.push('Using ' + q.usedRows + ' of ' + q.rowCount + ' rows');
        }
        return msgs;
    }

    function appendText(parent, text) {
        parent.appendChild(document.createTextNode(text));
    }

    function createSvgEl(name) {
        return document.createElementNS('http://www.w3.org/2000/svg', name);
    }

    function piePath(cx, cy, r, startAngle, sweep) {
        var endAngle = startAngle + sweep;
        var x1 = cx + r * Math.cos(startAngle);
        var y1 = cy + r * Math.sin(startAngle);
        var x2 = cx + r * Math.cos(endAngle);
        var y2 = cy + r * Math.sin(endAngle);
        var large = sweep > Math.PI ? 1 : 0;
        return (
            'M' +
            cx +
            ' ' +
            cy +
            ' L' +
            x1.toFixed(2) +
            ' ' +
            y1.toFixed(2) +
            ' A' +
            r +
            ' ' +
            r +
            ' 0 ' +
            large +
            ' 1 ' +
            x2.toFixed(2) +
            ' ' +
            y2.toFixed(2) +
            ' Z'
        );
    }

    function donutPath(cx, cy, outerR, innerR, startAngle, sweep) {
        var endAngle = startAngle + sweep;
        var large = sweep > Math.PI ? 1 : 0;
        var ox1 = cx + outerR * Math.cos(startAngle);
        var oy1 = cy + outerR * Math.sin(startAngle);
        var ox2 = cx + outerR * Math.cos(endAngle);
        var oy2 = cy + outerR * Math.sin(endAngle);
        var ix1 = cx + innerR * Math.cos(startAngle);
        var iy1 = cy + innerR * Math.sin(startAngle);
        var ix2 = cx + innerR * Math.cos(endAngle);
        var iy2 = cy + innerR * Math.sin(endAngle);
        return (
            'M' +
            ox1.toFixed(2) +
            ' ' +
            oy1.toFixed(2) +
            ' A' +
            outerR +
            ' ' +
            outerR +
            ' 0 ' +
            large +
            ' 1 ' +
            ox2.toFixed(2) +
            ' ' +
            oy2.toFixed(2) +
            ' L' +
            ix2.toFixed(2) +
            ' ' +
            iy2.toFixed(2) +
            ' A' +
            innerR +
            ' ' +
            innerR +
            ' 0 ' +
            large +
            ' 0 ' +
            ix1.toFixed(2) +
            ' ' +
            iy1.toFixed(2) +
            ' Z'
        );
    }

    function appendPieSlice(svg, cx, cy, outerR, innerR, startAngle, sweep, fill, stroke) {
        var path;
        var hole;
        if (sweep >= Math.PI * 2 - 1e-6) {
            path = createSvgEl('circle');
            path.setAttribute('cx', String(cx));
            path.setAttribute('cy', String(cy));
            path.setAttribute('r', String(outerR));
            if (innerR > 0) {
                hole = createSvgEl('circle');
                hole.setAttribute('cx', String(cx));
                hole.setAttribute('cy', String(cy));
                hole.setAttribute('r', String(innerR));
                hole.setAttribute('fill', stroke);
            }
        } else {
            path = createSvgEl('path');
            path.setAttribute('d', innerR > 0 ? donutPath(cx, cy, outerR, innerR, startAngle, sweep) : piePath(cx, cy, outerR, startAngle, sweep));
        }
        path.setAttribute('fill', fill);
        path.setAttribute('stroke', stroke);
        path.setAttribute('stroke-width', '1.5');
        path.setAttribute('class', 'bgdhamp-pie-chart-viz__slice');
        svg.appendChild(path);
        if (hole) {
            svg.appendChild(hole);
        }
        return path;
    }

    function clampNumber(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    function truncateText(value, maxLength) {
        var text = String(value == null ? '' : value);
        var limit = maxLength || 30;
        if (text.length <= limit) {
            return text;
        }
        return text.slice(0, Math.max(0, limit - 3)) + '...';
    }

    function calloutSecondaryText(slice, opts) {
        var parts = [];
        if (opts.showValue) {
            parts.push(valueText(slice.value));
        }
        if (opts.showPercent) {
            parts.push(pctText(slice.percent, 1));
        }
        return parts.join(' · ');
    }

    function distributeCalloutYs(items, minY, maxY, gap) {
        var i;
        var overflow;
        items.sort(function (a, b) {
            return a.targetY - b.targetY;
        });
        for (i = 0; i < items.length; i += 1) {
            items[i].y = clampNumber(items[i].targetY, minY, maxY);
            if (i > 0 && items[i].y < items[i - 1].y + gap) {
                items[i].y = items[i - 1].y + gap;
            }
        }
        if (items.length) {
            overflow = items[items.length - 1].y - maxY;
            if (overflow > 0) {
                for (i = 0; i < items.length; i += 1) {
                    items[i].y -= overflow;
                }
            }
            for (i = 0; i < items.length; i += 1) {
                if (i === 0 && items[i].y < minY) {
                    items[i].y = minY;
                } else if (i > 0 && items[i].y < items[i - 1].y + gap) {
                    items[i].y = items[i - 1].y + gap;
                }
            }
        }
        return items;
    }

    function appendSliceCallouts(svg, slices, angles, geometry, opts) {
        var left = [];
        var right = [];
        var callouts = [];
        var minY = 18;
        var maxY = geometry.height - 18;
        var gap = opts.showPercent || opts.showValue ? 22 : 16;
        var i;
        // Keep callouts off the legend/inspector side so labels don't stack on the side panel.
        var allowLeft = opts.calloutSides !== 'right';
        var allowRight = opts.calloutSides !== 'left';

        for (i = 0; i < slices.length; i += 1) {
            var angle = angles[i];
            var side;
            var item;
            if (!isFinite(angle) || slices[i].percent < opts.sliceLabelMinPercent) {
                callouts[i] = null;
                continue;
            }
            side = Math.cos(angle) >= 0 ? 'right' : 'left';
            if ((side === 'left' && !allowLeft) || (side === 'right' && !allowRight)) {
                callouts[i] = null;
                continue;
            }
            item = {
                idx: i,
                angle: angle,
                side: side,
                targetY: geometry.cy + Math.sin(angle) * (geometry.outerR + 28),
            };
            if (side === 'right') {
                right.push(item);
            } else {
                left.push(item);
            }
        }

        distributeCalloutYs(left, minY, maxY, gap)
            .concat(distributeCalloutYs(right, minY, maxY, gap))
            .forEach(function (item) {
                var cos = Math.cos(item.angle);
                var sin = Math.sin(item.angle);
                var edgeX = geometry.cx + cos * (geometry.outerR + 2);
                var edgeY = geometry.cy + sin * (geometry.outerR + 2);
                var isRight = item.side === 'right';
                var labelX = isRight ? geometry.width - 12 : 12;
                var midX = geometry.cx + cos * (geometry.outerR + 18);
                var elbowX = isRight ? labelX - 8 : labelX + 8;
                var secondary = calloutSecondaryText(slices[item.idx], opts);
                var group = createSvgEl('g');
                var line = createSvgEl('polyline');
                var text = createSvgEl('text');
                var nameTspan = createSvgEl('tspan');
                var valueTspan;

                group.setAttribute('class', 'bgdhamp-pie-chart-viz__callout');
                group.setAttribute('tabindex', '0');
                group.setAttribute('data-slice-index', String(item.idx));

                line.setAttribute('class', 'bgdhamp-pie-chart-viz__callout-line');
                line.setAttribute(
                    'points',
                    edgeX.toFixed(2) +
                        ',' +
                        edgeY.toFixed(2) +
                        ' ' +
                        midX.toFixed(2) +
                        ',' +
                        item.y.toFixed(2) +
                        ' ' +
                        elbowX.toFixed(2) +
                        ',' +
                        item.y.toFixed(2)
                );

                text.setAttribute('class', 'bgdhamp-pie-chart-viz__callout-text');
                text.setAttribute('x', String(labelX));
                text.setAttribute('y', String(secondary ? item.y - 6 : item.y));
                text.setAttribute('text-anchor', isRight ? 'end' : 'start');
                text.setAttribute('fill', opts.textColor);

                nameTspan.setAttribute('x', String(labelX));
                nameTspan.setAttribute('dy', '0');
                nameTspan.textContent = truncateText(slices[item.idx].label, 28);
                text.appendChild(nameTspan);

                if (secondary) {
                    valueTspan = createSvgEl('tspan');
                    valueTspan.setAttribute('class', 'bgdhamp-pie-chart-viz__callout-value');
                    valueTspan.setAttribute('x', String(labelX));
                    valueTspan.setAttribute('dy', '12');
                    valueTspan.textContent = secondary;
                    text.appendChild(valueTspan);
                }

                group.appendChild(line);
                group.appendChild(text);
                svg.appendChild(group);
                callouts[item.idx] = group;
            });

        return callouts;
    }

    function eventPoint(root, e, fallbackEl) {
        var rootRect = root.getBoundingClientRect();
        var fallbackRect;
        if (e && isFinite(e.clientX) && isFinite(e.clientY)) {
            return {
                x: e.clientX - rootRect.left,
                y: e.clientY - rootRect.top,
            };
        }
        if (fallbackEl && typeof fallbackEl.getBoundingClientRect === 'function') {
            fallbackRect = fallbackEl.getBoundingClientRect();
            return {
                x: fallbackRect.left + fallbackRect.width / 2 - rootRect.left,
                y: fallbackRect.top + fallbackRect.height / 2 - rootRect.top,
            };
        }
        return {
            x: root.clientWidth / 2,
            y: root.clientHeight / 2,
        };
    }

    function clampTooltip(tooltip, root, x, y) {
        var width = tooltip.offsetWidth || 190;
        var height = tooltip.offsetHeight || 110;
        var maxX = Math.max(8, root.clientWidth - width - 8);
        var maxY = Math.max(8, root.clientHeight - height - 8);
        tooltip.style.left = Math.max(8, Math.min(x + 14, maxX)) + 'px';
        tooltip.style.top = Math.max(8, Math.min(y + 14, maxY)) + 'px';
    }

    function setTooltip(tooltip, slice, model, opts, root, e, fallbackEl) {
        if (!tooltip || !slice || !opts.showTooltip) {
            return;
        }
        var point = eventPoint(root, e, fallbackEl);
        tooltip.innerHTML = '';
        tooltip.style.display = 'block';
        tooltip.style.visibility = 'hidden';

        var title = document.createElement('div');
        title.className = 'bgdhamp-pie-chart-viz__tooltip-title';
        title.textContent = slice.label;
        tooltip.appendChild(title);
        addMetric(tooltip, 'Value', valueText(slice.value));
        addMetric(tooltip, 'Percent', pctText(slice.percent, 1));
        if (opts.showRowCount) {
            addMetric(tooltip, 'Rows', valueText(slice.rowCount));
        }
        if (opts.showCompare && slice.compareValue !== null) {
            addMetric(tooltip, 'Compare', valueText(slice.compareValue));
            addMetric(tooltip, 'Delta', compareText(slice));
        }
        if (slice.isOther && opts.showOtherBreakdown && slice.members && slice.members.length) {
            addBreakdown(tooltip, slice.members, model.total);
        }
        clampTooltip(tooltip, root, point.x, point.y);
        tooltip.style.visibility = 'visible';
    }

    function addMetric(parent, label, value) {
        var row = document.createElement('div');
        row.className = 'bgdhamp-pie-chart-viz__metric';
        var key = document.createElement('span');
        key.textContent = label;
        var val = document.createElement('strong');
        val.textContent = value;
        row.appendChild(key);
        row.appendChild(val);
        parent.appendChild(row);
    }

    function addBreakdown(parent, members, total) {
        var wrap = document.createElement('div');
        var title = document.createElement('div');
        var i;
        wrap.className = 'bgdhamp-pie-chart-viz__breakdown';
        title.className = 'bgdhamp-pie-chart-viz__breakdown-title';
        title.textContent = 'Other breakdown';
        wrap.appendChild(title);
        for (i = 0; i < Math.min(6, members.length); i += 1) {
            var row = document.createElement('div');
            row.className = 'bgdhamp-pie-chart-viz__breakdown-row';
            row.textContent =
                members[i].label +
                ': ' +
                valueText(members[i].value) +
                ' (' +
                pctText(total > 0 ? (members[i].value / total) * 100 : 0, 1) +
                ')';
            wrap.appendChild(row);
        }
        if (members.length > 6) {
            var more = document.createElement('div');
            more.className = 'bgdhamp-pie-chart-viz__breakdown-row';
            more.textContent = '+' + (members.length - 6) + ' more';
            wrap.appendChild(more);
        }
        parent.appendChild(wrap);
    }

    function updateInspector(inspector, slice, opts, model) {
        if (!inspector || !opts.showInspector) {
            return;
        }
        inspector.innerHTML = '';
        var label = document.createElement('div');
        label.className = 'bgdhamp-pie-chart-viz__inspector-label';
        label.textContent = slice ? slice.label : 'Slice inspector';
        inspector.appendChild(label);
        if (!slice) {
            var hint = document.createElement('div');
            hint.className = 'bgdhamp-pie-chart-viz__inspector-hint';
            hint.textContent = 'Hover or select a slice to inspect contribution, rank, row count, and compare delta.';
            inspector.appendChild(hint);
            return;
        }
        addMetric(inspector, 'Value', valueText(slice.value));
        addMetric(inspector, 'Percent', pctText(slice.percent, 1));
        addMetric(inspector, 'Rows', valueText(slice.rowCount));
        if (slice.rank !== null) {
            addMetric(inspector, 'Rank', '#' + slice.rank + ' of ' + model.originalSliceCount);
        }
        if (opts.showCompare && slice.compareValue !== null) {
            addMetric(inspector, 'Prior', valueText(slice.compareValue));
            addMetric(inspector, 'Delta', compareText(slice));
        }
        if (slice.isOther && opts.showOtherBreakdown && slice.members && slice.members.length) {
            addBreakdown(inspector, slice.members, model.total);
        }
    }

    function makeFilterClause(fieldNameValue, label) {
        var labelText = String(label == null ? '' : label);
        var field = String(fieldNameValue || '').trim();
        var escaped = labelText.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        if (!field) {
            return 'search "' + escaped + '"';
        }
        return field + '="' + escaped + '"';
    }

    function tokenMap(detail, prefix) {
        var p = prefix || 'pie';
        var map = {};
        map[p + '_label'] = detail.label;
        map[p + '_value'] = String(detail.value);
        map[p + '_percent'] = String(detail.percent);
        map[p + '_rank'] = detail.rank == null ? '' : String(detail.rank);
        map[p + '_rows'] = String(detail.rowCount);
        map[p + '_label_field'] = detail.labelField;
        map[p + '_value_field'] = detail.valueField;
        map[p + '_filter_clause'] = detail.filterClause;
        map[p + '_compare_value'] = detail.compareValue == null ? '' : String(detail.compareValue);
        map[p + '_compare_delta'] = detail.compareDelta == null ? '' : String(detail.compareDelta);
        return map;
    }

    function setSplunkTokens(ownerDoc, prefix, detail) {
        var win = (ownerDoc && ownerDoc.defaultView) || window;
        var req = win && win.require;
        var values = tokenMap(detail, prefix);
        if (typeof req !== 'function') {
            return;
        }
        try {
            req(['splunkjs/mvc'], function (mvc) {
                ['default', 'submitted'].forEach(function (modelName) {
                    var model = mvc && mvc.Components && mvc.Components.get(modelName);
                    if (!model || typeof model.set !== 'function') {
                        return;
                    }
                    Object.keys(values).forEach(function (key) {
                        model.set(key, values[key]);
                    });
                });
            });
        } catch (ignore) {}
    }

    function substituteTokens(template, values) {
        var out = String(template || '');
        Object.keys(values).forEach(function (key) {
            out = out.split('$' + key + '$').join(values[key]);
        });
        return out;
    }

    function maybeNavigateSearch(ownerDoc, opts, detail) {
        var action = String(opts.drilldownAction || 'tokens').toLowerCase();
        var win = (ownerDoc && ownerDoc.defaultView) || window;
        var query;
        var params;
        if (action !== 'search' && action !== 'both') {
            return;
        }
        query = substituteTokens(opts.drilldownQuery, tokenMap(detail, opts.tokenPrefix));
        params = new URLSearchParams();
        params.set('q', query || detail.filterClause || '*');
        win.location.href = '/app/search/search?' + params.toString();
    }

    function sliceDetail(slice, model) {
        var compareDelta = slice.compareValue === null ? null : slice.value - slice.compareValue;
        return {
            label: slice.label,
            value: slice.value,
            percent: slice.percent,
            rank: slice.rank,
            rowCount: slice.rowCount,
            compareValue: slice.compareValue,
            compareDelta: compareDelta,
            labelField: model.picked.labelFieldName,
            valueField: model.picked.valueFieldName,
            filterClause: makeFilterClause(model.picked.labelFieldName, slice.label),
            isOther: !!slice.isOther,
            members: slice.members || [],
        };
    }

    function buildModel(rawData, opts) {
        var base = buildSlices(rawData, opts);
        var shaped = shapeSlices(base.slices, opts, base.quality);
        return {
            slices: shaped.slices,
            total: shaped.total,
            originalSliceCount: shaped.originalSliceCount,
            fields: base.fields,
            picked: base.picked,
            quality: base.quality,
            error: base.error,
        };
    }

    return SplunkVisualizationBase.extend({
        initialize: function () {
            // Splunk Enterprise 9.4 custom viz lifecycle
            if (this.el && this.el.classList) {
                this.el.classList.add('bgdhamp-pie-chart-viz-host');
            }
            this._lastData = null;
            this._lastConfig = null;
        },

        getInitialDataParams: function () {
            return {
                outputMode: SplunkVisualizationBase.COLUMN_MAJOR_OUTPUT_MODE,
                count: 10000,
            };
        },

        formatData: function (rawData) {
            return { rawData: rawData || { columns: [], fields: [] } };
        },

        updateView: function (data, config) {
            var viz = this;
            readConfig._activeViz = viz;
            var ownerDoc = (this.el && this.el.ownerDocument) || document;
            if (config == null || typeof config !== 'object') {
                config = {};
            }
            this._lastData = data;
            this._lastConfig = config;
            if (this._infoCleanup) {
                this._infoCleanup();
                this._infoCleanup = null;
            }
            if (this._pieCleanup) {
                this._pieCleanup();
                this._pieCleanup = null;
            }
            this.el.innerHTML = '';

            var opts = readOptions(config);
            var rawData = (data && data.rawData) || {};
            var model = buildModel(rawData, opts);
            var slices = model.slices;
            var total = model.total;
            var stringFields = collectStringFields(rawData);
            var textCells = collectTextCells(stringFields, config);
            var showInfo = readBool(config, 'showInfo', false);
            var infoText = '';
            var i;
            var cleanup = [];

            if (showInfo) {
                infoText = String(readConfig(config, 'infoText', '') || '').trim();
                if (!infoText) {
                    infoText = lastStringValue(
                        stringFields,
                        String(readConfig(config, 'infoField', 'info') || 'info')
                    );
                }
                showInfo = !!infoText;
            }

            this.el.style.backgroundColor = opts.background;
            this.el.style.setProperty('background-color', opts.background, 'important');
            this.el.style.color = opts.textColor;
            this.el.setAttribute('data-pie-token-prefix', opts.tokenPrefix);
            this.el.setAttribute('data-bgdhamp-viz-build', VIZ_BUILD);

            if (model.error || !slices.length || total <= 0) {
                var emptyRoot = document.createElement('div');
                emptyRoot.className = 'bgdhamp-pie-chart-viz bgdhamp-pie-chart-viz--empty';
                emptyRoot.setAttribute('data-bgdhamp-viz-build', VIZ_BUILD);
                emptyRoot.style.backgroundColor = opts.background;
                emptyRoot.style.color = opts.textColor;
                emptyRoot.style.width = '100%';
                emptyRoot.style.height = '100%';
                var empty = document.createElement('div');
                empty.className = 'bgdhamp-pie-chart-viz__err';
                empty.textContent = model.error || opts.emptyMessage;
                emptyRoot.appendChild(empty);
                this.el.appendChild(emptyRoot);
                return;
            }

            var legendPos = String(opts.legendPosition || 'none').toLowerCase();
            if (legendPos !== 'left' && legendPos !== 'right' && legendPos !== 'top' && legendPos !== 'bottom') {
                legendPos = 'none';
            }
            // Slice callouts + side legend in the same gutter overlap; park left/right legend under the pie.
            var stackSideBelow =
                opts.showSliceLabels && (legendPos === 'left' || legendPos === 'right' || opts.showInspector);
            var layoutLegend = legendPos;
            if (stackSideBelow && (legendPos === 'left' || legendPos === 'right')) {
                layoutLegend = 'bottom';
            }
            // Once stacked below, both callout sides are free again.
            opts.calloutSides = stackSideBelow
                ? 'both'
                : legendPos === 'left'
                  ? 'right'
                  : legendPos === 'right'
                    ? 'left'
                    : 'both';

            var root = document.createElement('div');
            root.className =
                'bgdhamp-pie-chart-viz bgdhamp-pie-chart-viz--legend-' + layoutLegend;
            if (opts.showSliceLabels) {
                root.className += ' bgdhamp-pie-chart-viz--slice-labels';
            }
            if (stackSideBelow) {
                root.className += ' bgdhamp-pie-chart-viz--stack-side';
            }
            root.style.backgroundColor = opts.background;
            root.style.color = opts.textColor;
            root.setAttribute('data-bgdhamp-viz-build', VIZ_BUILD);

            if (opts.title) {
                var head = document.createElement('div');
                head.className = 'bgdhamp-pie-chart-viz__title';
                head.textContent = opts.title;
                if (showInfo) {
                    head.style.paddingRight = 8 + INFO_ICON_SIZE_PX + 8 + 'px';
                }
                root.appendChild(head);
            }

            if (textCells.length) {
                var textRow = ownerDoc.createElement('div');
                textRow.className = 'bgdhamp-pie-chart-viz__textRow';
                textRow.style.display = 'flex';
                textRow.style.flexDirection = 'row';
                textRow.style.alignItems = 'stretch';
                textRow.style.width = '100%';
                textRow.style.flex = '0 0 ' + TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.height = TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.boxSizing = 'border-box';
                textRow.style.overflow = 'hidden';
                textRow.style.background = opts.textRowBackground;
                textRow.style.setProperty('background', opts.textRowBackground, 'important');
                textRow.style.color = opts.textColor;
                textRow.style.fontWeight = '400';
                textRow.style.textShadow = 'none';
                var linkPrefix = splunkPathPrefix(ownerDoc);
                var linkTarget =
                    String(readConfig(config, 'linkTarget', 'newTab') || '')
                        .replace(/[^a-z0-9]+/gi, '')
                        .toLowerCase() === 'sametab'
                        ? '_self'
                        : '_blank';
                var linkEarliest = String(readConfig(config, 'linkEarliest', '') || '');
                var linkLatest = String(readConfig(config, 'linkLatest', '') || '');
                var ci;
                for (ci = 0; ci < textCells.length; ci += 1) {
                    var tc = textCells[ci];
                    var cellTextLabel = tc.label ? tc.label + ': ' + tc.value : tc.value;
                    var href =
                        cellUrl(tc.urlTpl, tc.urlFromField, tc.value, tc.label, linkPrefix) ||
                        buildSearchLink(
                            tc.searchTpl,
                            tc.value,
                            tc.label,
                            linkEarliest,
                            linkLatest,
                            linkPrefix
                        );
                    var cell = href
                        ? makeLinkCell(ownerDoc, href, linkTarget)
                        : ownerDoc.createElement('div');
                    styleTextCell(cell, ci === 0);
                    cell.textContent = cellTextLabel;
                    cell.setAttribute('title', cellTextLabel);
                    textRow.appendChild(cell);
                }
                root.appendChild(textRow);
            }

            if (showInfo) {
                var infoTopPx = opts.title ? 5 : 6;
                this._infoCleanup = mountInfoPopover(viz, root, ownerDoc, infoText, infoTopPx);
            }

            if (opts.showDataQuality) {
                var qMessages = qualityMessages(model);
                if (qMessages.length) {
                    var banner = document.createElement('div');
                    banner.className = 'bgdhamp-pie-chart-viz__quality';
                    banner.textContent = qMessages.join('; ');
                    root.appendChild(banner);
                }
            }

            var main = document.createElement('div');
            main.className = 'bgdhamp-pie-chart-viz__main';

            var pieBox = document.createElement('div');
            pieBox.className = 'bgdhamp-pie-chart-viz__pie';
            if (opts.showSliceLabels) {
                pieBox.className += ' bgdhamp-pie-chart-viz__pie--slice-labels';
            }
            var svg = createSvgEl('svg');
            // Compact geometry so the full pie fits short dashboard tiles (avoids bottom clipping).
            var geometry = opts.showSliceLabels
                ? { width: 520, height: 260, cx: 260, cy: 130, outerR: 78 }
                : { width: 200, height: 200, cx: 100, cy: 100, outerR: 82 };
            svg.setAttribute('viewBox', '0 0 ' + geometry.width + ' ' + geometry.height);
            svg.setAttribute('width', '100%');
            svg.setAttribute('height', '100%');
            svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
            svg.setAttribute('role', 'img');
            svg.setAttribute('aria-label', 'Pie chart: ' + valueText(total) + ' total');
            svg.style.color = opts.textColor;

            var tooltip = document.createElement('div');
            tooltip.className = 'bgdhamp-pie-chart-viz__tooltip';
            tooltip.style.display = 'none';

            var side = document.createElement('div');
            side.className = 'bgdhamp-pie-chart-viz__side';

            var inspector = null;
            if (opts.showInspector) {
                inspector = document.createElement('div');
                inspector.className = 'bgdhamp-pie-chart-viz__inspector';
                updateInspector(inspector, slices[0], opts, model);
                side.appendChild(inspector);
            }

            var legend = document.createElement('div');
            legend.className = 'bgdhamp-pie-chart-viz__legend';

            var cx = geometry.cx;
            var cy = geometry.cy;
            var outerR = geometry.outerR;
            var innerR = Math.min(opts.innerRadius, Math.max(0, outerR - 8));
            var angle = -Math.PI / 2;
            var paths = [];
            var rows = [];
            var callouts = [];
            var sliceAngles = [];

            function clearActive() {
                paths.forEach(function (p) {
                    p.classList.remove('bgdhamp-pie-chart-viz__slice--active');
                    p.classList.remove('bgdhamp-pie-chart-viz__slice--dim');
                });
                callouts.forEach(function (callout) {
                    if (!callout) {
                        return;
                    }
                    callout.classList.remove('bgdhamp-pie-chart-viz__callout--active');
                    callout.classList.remove('bgdhamp-pie-chart-viz__callout--dim');
                });
                rows.forEach(function (row) {
                    row.classList.remove('bgdhamp-pie-chart-viz__legend-row--active');
                    row.classList.remove('bgdhamp-pie-chart-viz__legend-row--dim');
                });
            }

            function setActive(idx, e) {
                clearActive();
                paths.forEach(function (p, pi) {
                    p.classList.toggle('bgdhamp-pie-chart-viz__slice--dim', pi !== idx);
                });
                callouts.forEach(function (callout, ci) {
                    if (callout) {
                        callout.classList.toggle('bgdhamp-pie-chart-viz__callout--dim', ci !== idx);
                    }
                });
                rows.forEach(function (row, ri) {
                    row.classList.toggle('bgdhamp-pie-chart-viz__legend-row--dim', ri !== idx);
                });
                paths[idx].classList.add('bgdhamp-pie-chart-viz__slice--active');
                if (callouts[idx]) {
                    callouts[idx].classList.add('bgdhamp-pie-chart-viz__callout--active');
                }
                if (rows[idx]) {
                    rows[idx].classList.add('bgdhamp-pie-chart-viz__legend-row--active');
                }
                updateInspector(inspector, slices[idx], opts, model);
                if (e) {
                    setTooltip(tooltip, slices[idx], model, opts, root, e, paths[idx]);
                }
            }

            function hideTooltip() {
                tooltip.style.display = 'none';
                tooltip.style.visibility = 'hidden';
            }

            function activateClick(idx) {
                var detail = sliceDetail(slices[idx], model);
                var ownerDoc = root.ownerDocument || document;
                root.setAttribute('data-pie-label', detail.label);
                root.setAttribute('data-pie-value', String(detail.value));
                root.setAttribute('data-pie-percent', String(detail.percent));
                root.setAttribute('data-pie-filter-clause', detail.filterClause);
                if (opts.drilldown) {
                    setSplunkTokens(ownerDoc, opts.tokenPrefix, detail);
                    maybeNavigateSearch(ownerDoc, opts, detail);
                }
                try {
                    root.dispatchEvent(
                        new CustomEvent('splunkstuff:pie-slice-click', {
                            bubbles: true,
                            detail: detail,
                        })
                    );
                } catch (ignore) {}
            }

            for (i = 0; i < slices.length; i += 1) {
                var frac = slices[i].value / total;
                var sweep = frac * Math.PI * 2;
                if (sweep <= 0) {
                    continue;
                }
                sliceAngles[i] = angle + sweep / 2;
                var path = appendPieSlice(
                    svg,
                    cx,
                    cy,
                    outerR,
                    innerR,
                    angle,
                    sweep,
                    slices[i].color,
                    opts.background
                );
                path.setAttribute('tabindex', '0');
                path.setAttribute(
                    'aria-label',
                    slices[i].label +
                        ', ' +
                        valueText(slices[i].value) +
                        ', ' +
                        pctText(slices[i].percent, 1)
                );
                path.setAttribute('data-slice-index', String(i));
                paths.push(path);
                angle += sweep;
            }

            if (opts.showSliceLabels) {
                callouts = appendSliceCallouts(svg, slices, sliceAngles, geometry, opts);
            }

            paths.forEach(function (path, idx) {
                var enter = function (e) {
                    setActive(idx, e);
                };
                var move = function (e) {
                    setTooltip(tooltip, slices[idx], model, opts, root, e, path);
                };
                var leave = function () {
                    hideTooltip();
                };
                var focus = function (e) {
                    setActive(idx);
                    setTooltip(tooltip, slices[idx], model, opts, root, e, path);
                };
                var click = function () {
                    activateClick(idx);
                };
                var keydown = function (e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        activateClick(idx);
                    }
                };
                path.addEventListener('pointerenter', enter);
                path.addEventListener('pointermove', move);
                path.addEventListener('pointerleave', leave);
                path.addEventListener('mouseenter', enter);
                path.addEventListener('mousemove', move);
                path.addEventListener('mouseleave', leave);
                path.addEventListener('focus', focus);
                path.addEventListener('blur', leave);
                path.addEventListener('click', click);
                path.addEventListener('keydown', keydown);
                cleanup.push(function () {
                    path.removeEventListener('pointerenter', enter);
                    path.removeEventListener('pointermove', move);
                    path.removeEventListener('pointerleave', leave);
                    path.removeEventListener('mouseenter', enter);
                    path.removeEventListener('mousemove', move);
                    path.removeEventListener('mouseleave', leave);
                    path.removeEventListener('focus', focus);
                    path.removeEventListener('blur', leave);
                    path.removeEventListener('click', click);
                    path.removeEventListener('keydown', keydown);
                });
            });

            callouts.forEach(function (callout, idx) {
                if (!callout) {
                    return;
                }
                var enter = function (e) {
                    setActive(idx, e);
                };
                var move = function (e) {
                    setTooltip(tooltip, slices[idx], model, opts, root, e, callout);
                };
                var leave = function () {
                    hideTooltip();
                };
                var focus = function (e) {
                    setActive(idx);
                    setTooltip(tooltip, slices[idx], model, opts, root, e, callout);
                };
                var click = function () {
                    activateClick(idx);
                };
                var keydown = function (e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        activateClick(idx);
                    }
                };
                callout.addEventListener('pointerenter', enter);
                callout.addEventListener('pointermove', move);
                callout.addEventListener('pointerleave', leave);
                callout.addEventListener('mouseenter', enter);
                callout.addEventListener('mousemove', move);
                callout.addEventListener('mouseleave', leave);
                callout.addEventListener('focus', focus);
                callout.addEventListener('blur', leave);
                callout.addEventListener('click', click);
                callout.addEventListener('keydown', keydown);
                cleanup.push(function () {
                    callout.removeEventListener('pointerenter', enter);
                    callout.removeEventListener('pointermove', move);
                    callout.removeEventListener('pointerleave', leave);
                    callout.removeEventListener('mouseenter', enter);
                    callout.removeEventListener('mousemove', move);
                    callout.removeEventListener('mouseleave', leave);
                    callout.removeEventListener('focus', focus);
                    callout.removeEventListener('blur', leave);
                    callout.removeEventListener('click', click);
                    callout.removeEventListener('keydown', keydown);
                });
            });

            pieBox.appendChild(svg);
            main.appendChild(pieBox);

            if (layoutLegend !== 'none') {
                for (i = 0; i < slices.length; i += 1) {
                    var row = document.createElement('button');
                    row.type = 'button';
                    row.className = 'bgdhamp-pie-chart-viz__legend-row';
                    var swatch = document.createElement('span');
                    swatch.className = 'bgdhamp-pie-chart-viz__swatch';
                    swatch.style.backgroundColor = slices[i].color;
                    var text = document.createElement('span');
                    text.className = 'bgdhamp-pie-chart-viz__legend-text';
                    appendText(text, slices[i].label);
                    if (opts.showValue) {
                        appendText(text, ' - ' + valueText(slices[i].value));
                    }
                    if (opts.showPercent) {
                        appendText(text, ' (' + pctText(slices[i].percent, 1) + ')');
                    }
                    if (opts.showRowCount) {
                        appendText(text, ' - ' + valueText(slices[i].rowCount) + ' rows');
                    }
                    if (opts.showCompare && slices[i].compareValue !== null) {
                        appendText(text, ' - delta ' + compareText(slices[i]));
                    }
                    row.appendChild(swatch);
                    row.appendChild(text);
                    (function (idx, legendRow) {
                        var enter = function (e) {
                            setActive(idx, e);
                        };
                        var move = function (e) {
                            setTooltip(tooltip, slices[idx], model, opts, root, e, legendRow);
                        };
                        var leave = function () {
                            hideTooltip();
                        };
                        var focus = function (e) {
                            setActive(idx);
                            setTooltip(tooltip, slices[idx], model, opts, root, e, legendRow);
                        };
                        var click = function () {
                            activateClick(idx);
                        };
                        legendRow.addEventListener('pointerenter', enter);
                        legendRow.addEventListener('pointermove', move);
                        legendRow.addEventListener('pointerleave', leave);
                        legendRow.addEventListener('mouseenter', enter);
                        legendRow.addEventListener('mousemove', move);
                        legendRow.addEventListener('mouseleave', leave);
                        legendRow.addEventListener('focus', focus);
                        legendRow.addEventListener('blur', leave);
                        legendRow.addEventListener('click', click);
                        cleanup.push(function () {
                            legendRow.removeEventListener('pointerenter', enter);
                            legendRow.removeEventListener('pointermove', move);
                            legendRow.removeEventListener('pointerleave', leave);
                            legendRow.removeEventListener('mouseenter', enter);
                            legendRow.removeEventListener('mousemove', move);
                            legendRow.removeEventListener('mouseleave', leave);
                            legendRow.removeEventListener('focus', focus);
                            legendRow.removeEventListener('blur', leave);
                            legendRow.removeEventListener('click', click);
                        });
                    })(i, row);
                    rows.push(row);
                    legend.appendChild(row);
                }
                side.appendChild(legend);
            }
            if (layoutLegend !== 'none' || opts.showInspector) {
                main.appendChild(side);
            }
            root.appendChild(main);
            root.appendChild(tooltip);
            this.el.appendChild(root);

            if (this.el && this.el.style) {
                this.el.style.pointerEvents = 'auto';
            }
            enableAncestorPointerEvents(this.el);

            this._pieCleanup = function () {
                var ci;
                for (ci = 0; ci < cleanup.length; ci += 1) {
                    cleanup[ci]();
                }
            };
        },

        reflow: function () {
            if (this._lastData) {
                this.updateView(this._lastData, this._lastConfig == null ? {} : this._lastConfig);
            }
        },

        remove: function () {
            if (this._infoCleanup) {
                this._infoCleanup();
                this._infoCleanup = null;
            }
            if (this._pieCleanup) {
                this._pieCleanup();
                this._pieCleanup = null;
            }
            this._lastData = null;
            this._lastConfig = null;
            this.el.innerHTML = '';
        },
    });
});
