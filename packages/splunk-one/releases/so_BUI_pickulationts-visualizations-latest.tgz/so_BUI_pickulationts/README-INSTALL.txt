so_BUI_pickulationts — custom visualizations package
Built: 202611111220

Fixes in this build:
- Format section labels no longer use parentheses (Search Format UI)
- [splunkstuff_kpi_line] registered in visualizations.conf

Install:
  tar -xzf so_BUI_pickulationts-visualizations-202611111220.tgz -C "$SPLUNK_HOME/etc/apps"
  $SPLUNK_HOME/bin/splunk restart
  Hard-refresh the browser (or private window) after install.
