so_BUI_pickulationts — custom visualizations package
Built: 202611021137

Contains appserver/static/visualizations/* plus default/visualizations.conf and app.conf.

Install:
  tar -xzf so_BUI_pickulationts-visualizations-202611021137.tgz -C "$SPLUNK_HOME/etc/apps"
  # If the app already exists, merge visualizations/ and visualizations.conf carefully,
  # or replace the app folder after backing it up.
  $SPLUNK_HOME/bin/splunk restart

Includes Classic AMD vizs such as:
  - splunkstuff_kpi_line (4-file, text row + info)
  - splunkstuff_kpi_sparkline
  - splunkstuff_pie_chart (text row + info)
  - and other viz folders present in stage at package time

Does NOT include React page bundles under appserver/static/pages (Profile/Risk), by design — those are large.
