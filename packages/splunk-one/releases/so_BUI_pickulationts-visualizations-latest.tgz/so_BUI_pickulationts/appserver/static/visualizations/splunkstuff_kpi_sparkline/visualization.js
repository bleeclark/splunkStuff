/* eslint-disable */
/**
 * Splunk custom visualization: KPI + labels + delta + sparkline (gallery-intended layout).
 * New viz id so Splunk loads fresh AMD module; labels use inline styles (CSS optional).
 */
define(['api/SplunkVisualizationBase'], function (SplunkVisualizationBase) {
    var NS = 'display.visualizations.custom.so_BUI_pickulationts.splunkstuff_kpi_sparkline.';
    var VIZ_BUILD = '20261027-kpi-spark-value-field';
    /** Layout budget: 35px subheader + 137px body = 172px panel default_height. */
    var SUBHEADER_HEIGHT_PX = 35;
    /** Optional text1..text3 strip between the subheader and the KPI body. */
    var TEXT_ROW_HEIGHT_PX = 28;
    var TEXT_ROW_SLOTS = 3;
    var INFO_ICON_SIZE_PX = 18;
    var BODY_FRAME_HEIGHT_PX = 137;
    var PANEL_DEFAULT_HEIGHT_PX = SUBHEADER_HEIGHT_PX + BODY_FRAME_HEIGHT_PX;
    var SPARK_STRIP_HEIGHT_PX = 36;
    /** Minimum vertical space reserved for KPI + delta above the spark. */
    var HEADLINE_MIN_PX = 64;
    /** Minimum space above spark before in-chart hover annotation is allowed. */
    var HOVER_ANN_MIN_GAP_PX = 28;
    var DEMO_LABELS = {
        majorLabel: '',
        deltaLabel: '',
        badgeText: '',
        sparkPointLabels: '',
    };
    /** Prefer these names when Format valueField is Auto (Single Value–like panels). */
    var VALUE_FIELD_HINTS = [
        'value',
        'total_count',
        'count',
        'total',
        'amount',
        'sum',
        'avg',
        'metric',
        'score',
    ];
    /** Skip Splunk metadata and text-row columns when Auto picks the Y series. */
    var SKIP_VALUE_FIELDS = {
        _time: true,
        _span: true,
        _spandays: true,
        _si: true,
        _serial: true,
        _cd: true,
        _indextime: true,
        linecount: true,
        text1: true,
        text2: true,
        text3: true,
        info: true,
    };

    function inlineCaptionStyle(el, textColor) {
        el.style.display = 'block';
        el.style.fontSize = '11px';
        el.style.fontWeight = '700';
        el.style.lineHeight = '1.15';
        el.style.color = textColor;
        el.style.textShadow = '0 1px 2px rgba(0,0,0,0.35)';
        el.style.padding = '1px 6px';
        el.style.borderRadius = '3px';
        el.style.background = 'rgba(0,0,0,0.28)';
        el.style.marginBottom = '1px';
        el.style.textAlign = 'center';
    }

    function appendIndicatorPair(container, valueEl, labelText, textColor, position) {
        var pos = position === 'right' ? 'right' : 'above';
        var pair = document.createElement('div');
        pair.className =
            'bgdhamp-sparkline-value-viz__indicatorPair bgdhamp-sparkline-value-viz__indicatorPair--' +
            pos;
        pair.style.display = 'flex';
        pair.style.flexDirection = pos === 'right' ? 'row' : 'column';
        pair.style.alignItems = pos === 'right' ? 'baseline' : 'center';
        pair.style.justifyContent = 'center';
        pair.style.gap = pos === 'right' ? '8px' : '2px';

        function makeLabel() {
            var lbl = document.createElement('div');
            lbl.className = 'bgdhamp-sparkline-value-viz__indicatorLabel';
            lbl.textContent = labelText;
            inlineCaptionStyle(lbl, textColor);
            if (pos === 'right') {
                lbl.style.marginBottom = '0';
            }
            return lbl;
        }

        if (pos === 'right') {
            pair.appendChild(valueEl);
            if (labelText) {
                pair.appendChild(makeLabel());
            }
        } else {
            if (labelText) {
                pair.appendChild(makeLabel());
            }
            pair.appendChild(valueEl);
        }
        pair.style.setProperty('width', 'auto', 'important');
        pair.style.setProperty('max-width', 'none', 'important');
        pair.style.setProperty('flex', '0 0 auto', 'important');
        container.appendChild(pair);
        return pair;
    }

    function shrinkToContent(el) {
        if (!el) {
            return;
        }
        el.style.setProperty('display', 'inline-flex', 'important');
        el.style.setProperty('width', 'auto', 'important');
        el.style.setProperty('max-width', 'none', 'important');
        el.style.setProperty('min-width', '0', 'important');
        el.style.setProperty('flex', '0 0 auto', 'important');
        el.style.setProperty('box-sizing', 'border-box', 'important');
    }

    function applyHeadlineRowLayout(row, isInline) {
        if (!row) {
            return;
        }
        row.style.setProperty('display', 'flex', 'important');
        row.style.setProperty('flex-direction', isInline ? 'row' : 'column', 'important');
        row.style.setProperty('flex-wrap', isInline ? 'nowrap' : 'nowrap', 'important');
        row.style.setProperty('align-items', isInline ? 'baseline' : 'center', 'important');
        row.style.setProperty('justify-content', 'center', 'important');
        row.style.setProperty('gap', isInline ? '16px' : '8px', 'important');
        row.style.setProperty('width', isInline ? 'auto' : '100%', 'important');
        row.style.setProperty('max-width', '100%', 'important');
        row.style.setProperty('white-space', isInline ? 'nowrap' : 'normal', 'important');
        row.style.setProperty('text-align', 'center', 'important');
    }

    function inlineBadgeStyle(el) {
        el.style.position = 'absolute';
        el.style.top = '8px';
        el.style.right = '10px';
        el.style.zIndex = '6';
        el.style.setProperty('width', 'auto', 'important');
        el.style.maxWidth = '45%';
        el.style.padding = '5px 12px';
        el.style.fontSize = '12px';
        el.style.fontWeight = '700';
        el.style.lineHeight = '1.25';
        el.style.textAlign = 'right';
        el.style.color = '#fff';
        el.style.background = 'rgba(0,0,0,0.55)';
        el.style.border = '1px solid rgba(255,255,255,0.25)';
        el.style.borderRadius = '4px';
        el.style.boxShadow = '0 1px 4px rgba(0,0,0,0.25)';
        el.style.pointerEvents = 'none';
    }

    function lastStringValue(series, field) {
        var name = String(field == null ? '' : field).trim();
        if (!name || !series || !series.stringFields) {
            return '';
        }
        var col = series.stringFields[name];
        if (!col || !col.length) {
            return '';
        }
        var v = col[col.length - 1];
        return v == null ? '' : String(v).trim();
    }

    function fillTemplate(template, value, label) {
        return String(template)
            .split('$value$')
            .join(value)
            .split('$label$')
            .join(label);
    }

    /** SPL double-quoted string escaping so "$value$" stays one quoted token. */
    function escapeSplValue(v) {
        return String(v == null ? '' : v)
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"');
    }

    /** Splunk Web path before /app/ (locale and optional root_endpoint), e.g. /en-US. */
    function splunkPathPrefix(ownerDoc) {
        var win = ownerDoc && ownerDoc.defaultView;
        var p = win && win.location ? String(win.location.pathname || '') : '';
        var idx = p.indexOf('/app/');
        return idx > 0 ? p.slice(0, idx) : '';
    }

    function withSplunkPrefix(url, prefix) {
        if (!prefix) {
            return url;
        }
        if (url.indexOf('/app/') === 0 || url.indexOf('/manager/') === 0) {
            return prefix + url;
        }
        return url;
    }

    /** Only http(s) or same-origin single-slash paths; blocks javascript:, //host, /\host. */
    function isSafeUrlTemplate(template) {
        var t = String(template == null ? '' : template).trim();
        return /^https?:\/\//i.test(t) || /^\/(?![\/\\])/.test(t);
    }

    function buildUrlLink(template, value, label, prefix) {
        var t = String(template == null ? '' : template).trim();
        if (!t || !isSafeUrlTemplate(t)) {
            return '';
        }
        var url = fillTemplate(
            t,
            encodeURIComponent(value == null ? '' : value),
            encodeURIComponent(label == null ? '' : label)
        );
        return withSplunkPrefix(url, prefix || '');
    }

    function buildSearchLink(template, value, label, earliest, latest, prefix) {
        var t = String(template == null ? '' : template).trim();
        if (!t) {
            return '';
        }
        var spl = fillTemplate(t, escapeSplValue(value), escapeSplValue(label));
        var url = '/app/search/search?q=' + encodeURIComponent(spl);
        var e = String(earliest == null ? '' : earliest).trim();
        var l = String(latest == null ? '' : latest).trim();
        if (e) {
            url += '&earliest=' + encodeURIComponent(e);
        }
        if (l) {
            url += '&latest=' + encodeURIComponent(l);
        }
        return withSplunkPrefix(url, prefix || '');
    }

    /** Link URL wins over Link search; '' means render plain text. */
    function buildCellLink(urlTpl, searchTpl, value, label, earliest, latest, prefix) {
        return (
            buildUrlLink(urlTpl, value, label, prefix) ||
            buildSearchLink(searchTpl, value, label, earliest, latest, prefix)
        );
    }

    function resolveLinkTarget(raw) {
        var t = compactToken(raw);
        return t === 'sametab' || t === 'same' || t === 'self' ? '_self' : '_blank';
    }

    /**
     * "tinted" (default) darkens the tile color so existing panels look unchanged;
     * "custom" uses the Format menu pickers so the row stands apart from the tile.
     */
    function resolveTextRowColors(optOr, tileTextColor) {
        if (compactToken(optOr('textRowStyle', 'tinted')) !== 'custom') {
            return {
                custom: false,
                bg: 'rgba(0,0,0,0.18)',
                fg: tileTextColor,
                divider: 'rgba(255,255,255,0.25)',
                border: 'rgba(255,255,255,0.18)',
            };
        }
        var divider = sanitizeHexColor(optOr('textRowDividerColor', '#3D5A80'), '#3D5A80');
        return {
            custom: true,
            bg: sanitizeHexColor(optOr('textRowBackground', '#0B1F3B'), '#0B1F3B'),
            fg: sanitizeHexColor(optOr('textRowTextColor', '#FFFFFF'), '#FFFFFF'),
            divider: divider,
            border: divider,
        };
    }

    function styleTextCell(el, isFirst, dividerColor) {
        el.className = 'bgdhamp-sparkline-value-viz__textCell';
        el.style.setProperty('flex', '1 1 0', 'important');
        el.style.setProperty('width', 'auto', 'important');
        el.style.setProperty('min-width', '0', 'important');
        el.style.display = 'block';
        el.style.boxSizing = 'border-box';
        el.style.padding = '0 8px';
        el.style.lineHeight = TEXT_ROW_HEIGHT_PX + 'px';
        el.style.whiteSpace = 'nowrap';
        el.style.overflow = 'hidden';
        el.style.textOverflow = 'ellipsis';
        el.style.textAlign = 'center';
        el.style.fontSize = '12px';
        el.style.fontWeight = '500';
        if (!isFirst) {
            el.style.borderLeft = '1px solid ' + (dividerColor || 'rgba(255,255,255,0.25)');
        }
    }

    function makeLinkCell(ownerDoc, href, target) {
        var a = ownerDoc.createElement('a');
        a.setAttribute('href', href);
        a.setAttribute('target', target);
        a.setAttribute('rel', 'noopener noreferrer');
        a.style.setProperty('color', 'inherit', 'important');
        a.style.setProperty('text-decoration', 'none', 'important');
        a.style.cursor = 'pointer';
        function underline(on) {
            a.style.setProperty('text-decoration', on ? 'underline' : 'none', 'important');
        }
        a.addEventListener('mouseenter', function () {
            underline(true);
        });
        a.addEventListener('mouseleave', function () {
            if (ownerDoc.activeElement !== a) {
                underline(false);
            }
        });
        a.addEventListener('focus', function () {
            underline(true);
            a.style.outline = '2px solid currentColor';
            a.style.outlineOffset = '-2px';
        });
        a.addEventListener('blur', function () {
            underline(false);
            a.style.outline = 'none';
        });
        return a;
    }

    var infoPopoverSeq = 0;

    /**
     * (i) button in the tile's top-right. Hover/focus shows the popover, click pins it,
     * outside click or Esc closes. Popover is fixed on <body> so the panel's
     * overflow:hidden can't clip it. Returns a teardown function.
     */
    function mountInfoPopover(viz, root, ownerDoc, text, topPx, iconColor) {
        var btn = ownerDoc.createElement('button');
        btn.type = 'button';
        btn.className = 'bgdhamp-sparkline-value-viz__info';
        btn.setAttribute('aria-label', 'More information');
        btn.setAttribute('aria-expanded', 'false');
        btn.textContent = 'i';
        btn.style.position = 'absolute';
        btn.style.top = topPx + 'px';
        btn.style.right = '8px';
        btn.style.zIndex = '7';
        btn.style.width = INFO_ICON_SIZE_PX + 'px';
        btn.style.height = INFO_ICON_SIZE_PX + 'px';
        btn.style.padding = '0';
        btn.style.margin = '0';
        btn.style.border = '1.5px solid currentColor';
        btn.style.borderRadius = '50%';
        btn.style.background = 'rgba(0,0,0,0.2)';
        btn.style.color = iconColor || 'inherit';
        btn.style.font = 'italic 700 11px/1 Georgia, "Times New Roman", serif';
        btn.style.cursor = 'pointer';
        btn.style.display = 'flex';
        btn.style.alignItems = 'center';
        btn.style.justifyContent = 'center';
        btn.style.boxSizing = 'border-box';

        infoPopoverSeq += 1;
        var pop = ownerDoc.createElement('div');
        pop.id = 'bgdhamp-kpi-info-' + infoPopoverSeq;
        pop.className = 'bgdhamp-sparkline-value-viz__infoPopover';
        pop.setAttribute('role', 'tooltip');
        pop.textContent = text;
        pop.style.display = 'none';
        pop.style.position = 'fixed';
        pop.style.zIndex = '2147483646';
        pop.style.maxWidth = '280px';
        pop.style.padding = '8px 10px';
        pop.style.fontSize = '12px';
        pop.style.lineHeight = '1.4';
        pop.style.color = '#FFFFFF';
        pop.style.background = 'rgba(11,31,59,0.96)';
        pop.style.border = '1px solid rgba(255,255,255,0.25)';
        pop.style.borderRadius = '4px';
        pop.style.boxShadow = '0 2px 8px rgba(0,0,0,0.35)';
        pop.style.whiteSpace = 'pre-wrap';
        btn.setAttribute('aria-describedby', pop.id);

        var pinned = false;

        function place() {
            var rect = btn.getBoundingClientRect();
            var win = ownerDoc.defaultView || window;
            var vw = win.innerWidth || ownerDoc.documentElement.clientWidth || 0;
            pop.style.top = Math.round(rect.bottom + 6) + 'px';
            pop.style.right = Math.max(4, Math.round(vw - rect.right)) + 'px';
        }

        function show() {
            var bodyEl = ownerDoc.body || ownerDoc.documentElement;
            if (bodyEl && pop.parentNode !== bodyEl) {
                bodyEl.appendChild(pop);
            }
            place();
            pop.style.display = 'block';
            btn.setAttribute('aria-expanded', 'true');
            viz._infoOpen = true;
        }

        function hide() {
            pop.style.display = 'none';
            btn.setAttribute('aria-expanded', 'false');
            viz._infoOpen = false;
        }

        btn.addEventListener('mouseenter', show);
        btn.addEventListener('focus', show);
        btn.addEventListener('mouseleave', function () {
            if (!pinned) {
                hide();
            }
        });
        btn.addEventListener('blur', function () {
            if (!pinned) {
                hide();
            }
        });
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            pinned = !pinned;
            if (pinned) {
                show();
            } else {
                hide();
            }
        });

        function onDocClick(e) {
            if (!pinned) {
                return;
            }
            var t = e.target;
            if (t === btn || btn.contains(t) || t === pop || pop.contains(t)) {
                return;
            }
            pinned = false;
            hide();
        }

        function onKey(e) {
            if (e.key === 'Escape' || e.key === 'Esc') {
                if (pop.style.display !== 'none') {
                    pinned = false;
                    hide();
                    btn.focus();
                }
            }
        }

        ownerDoc.addEventListener('click', onDocClick, true);
        ownerDoc.addEventListener('keydown', onKey, true);
        root.appendChild(btn);

        return function teardownInfo() {
            ownerDoc.removeEventListener('click', onDocClick, true);
            ownerDoc.removeEventListener('keydown', onKey, true);
            if (pop.parentNode) {
                pop.parentNode.removeChild(pop);
            }
            viz._infoOpen = false;
        };
    }

    /** Latest value of the label field wins; a blank field keeps the Format menu label. */
    function cellLabel(series, labelField, fallbackLabel) {
        var fromField = lastStringValue(series, labelField);
        if (fromField) {
            return fromField;
        }
        return String(fallbackLabel == null ? '' : fallbackLabel);
    }

    /**
     * Format-menu Link URL wins when it is set and safe.
     * Otherwise the latest value of the link URL field is used, after the same safety check.
     */
    function cellUrl(urlTpl, urlFromField, value, label, prefix) {
        return (
            buildUrlLink(urlTpl, value, label, prefix) ||
            buildUrlLink(urlFromField, value, label, prefix)
        );
    }

    /**
     * Cells for text1..text3 whose latest value is non-empty; only these render,
     * so 1 used cell spans the row, 2 split it in half, 3 in thirds.
     */
    function collectTextCells(series, opt) {
        var cells = [];
        var i;
        for (i = 1; i <= TEXT_ROW_SLOTS; i += 1) {
            var field = String(opt('text' + i + 'Field', 'text' + i) || '').trim();
            var value = lastStringValue(series, field);
            if (!value) {
                continue;
            }
            var labelField = String(opt('text' + i + 'LabelField', '') || '').trim();
            var urlField = String(opt('text' + i + 'LinkUrlField', '') || '').trim();
            cells.push({
                slot: i,
                label: cellLabel(
                    series,
                    labelField,
                    String(opt('text' + i + 'Label', 'Text' + i) || '')
                ),
                value: value,
                urlTpl: String(opt('text' + i + 'LinkUrl', '') || ''),
                urlFromField: lastStringValue(series, urlField),
                searchTpl: String(opt('text' + i + 'LinkSearch', '') || ''),
            });
        }
        return cells;
    }

    function fieldsList(rawData) {
        if (rawData && rawData.fields && rawData.fields.length) {
            return rawData.fields;
        }
        if (rawData && rawData.meta && rawData.meta.fields && rawData.meta.fields.length) {
            return rawData.meta.fields;
        }
        return [];
    }

    function cellValue(cell) {
        if (cell == null) {
            return cell;
        }
        if (typeof cell === 'object' && cell.value != null && !Array.isArray(cell)) {
            return cell.value;
        }
        return cell;
    }

    /**
     * Splunk Single Value shows the first item in a multivalue cell.
     * Walk arrays and {value: ...} wrappers until that first item is plain.
     */
    function firstCellValue(raw) {
        var guard = 0;
        while (raw != null && guard < 6) {
            if (Array.isArray(raw)) {
                raw = raw.length ? raw[0] : null;
                guard += 1;
                continue;
            }
            if (typeof raw === 'object' && raw.value != null) {
                raw = raw.value;
                guard += 1;
                continue;
            }
            break;
        }
        return raw;
    }

    function parseNum(cell) {
        var n = parseFloat(firstCellValue(cellValue(cell)), 10);
        return isFinite(n) ? n : NaN;
    }

    function fieldName(fields, idx) {
        if (!fields || idx < 0 || idx >= fields.length) {
            return '';
        }
        var f = fields[idx];
        if (typeof f === 'string') {
            return f;
        }
        if (f != null && f.name != null) {
            return String(f.name);
        }
        return '';
    }

    function findTimeColumnIndex(rawData) {
        var fields = fieldsList(rawData);
        var i;
        for (i = 0; i < fields.length; i += 1) {
            if (fieldName(fields, i) === '_time') {
                return i;
            }
        }
        return -1;
    }

    function timeSortKey(rawData, timeIdx, rowIdx) {
        var cell = cellValue(rawData.columns[timeIdx][rowIdx]);
        if (cell == null || cell === '') {
            return 0;
        }
        if (typeof cell === 'number' && isFinite(cell)) {
            return cell;
        }
        var s = String(cell).trim();
        if (/^-?\d+(\.\d+)?$/.test(s)) {
            var n = parseFloat(s, 10);
            return isFinite(n) ? n : 0;
        }
        var ms = Date.parse(s);
        if (isFinite(ms)) {
            return ms / 1000;
        }
        var fb = parseFloat(s, 10);
        return isFinite(fb) ? fb : 0;
    }

    function propertyNamespace(viz) {
        if (viz && typeof viz.getPropertyNamespaceInfo === 'function') {
            try {
                var info = viz.getPropertyNamespaceInfo();
                if (info && info.propertyNamespace) {
                    return info.propertyNamespace;
                }
            } catch (ignoreErr) {
                /* SplunkVisualizationBase may not expose namespace in all contexts */
            }
        }
        return NS;
    }

    function readConfig(config, prop, defaultVal, viz) {
        var found = findConfigValue(config, prop, viz);
        if (!found.found || found.value === '') {
            return defaultVal;
        }
        return found.value;
    }

    function findConfigValue(config, prop, viz) {
        if (config == null || typeof config !== 'object') {
            return { found: false, value: undefined };
        }
        var ns = propertyNamespace(viz);
        var candidates = [
            ns + prop,
            NS + prop,
            'so_BUI_pickulationts.' + prop,
            'display.visualizations.custom.so_BUI_pickulationts.' + prop,
            prop,
        ];
        var ci;
        for (ci = 0; ci < candidates.length; ci += 1) {
            var v = config[candidates[ci]];
            if (v !== undefined && v !== null) {
                return { found: true, value: v };
            }
        }
        var suffix = '.' + prop;
        var keys = Object.keys(config);
        var ki;
        for (ki = 0; ki < keys.length; ki += 1) {
            var key = keys[ki];
            if (key.length >= suffix.length && key.slice(-suffix.length) === suffix) {
                var v2 = config[key];
                if (v2 !== undefined && v2 !== null) {
                    return { found: true, value: v2 };
                }
            }
        }
        return { found: false, value: undefined };
    }

    function truthy(raw) {
        var s = String(raw == null ? '' : raw).trim().toLowerCase();
        return s === '1' || s === 'true' || s === 'yes' || s === 'on';
    }

    function compactToken(raw) {
        return String(raw == null ? '' : raw)
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '');
    }

    function isPercentDelta(mode) {
        var t = compactToken(mode);
        return t === 'percent' || t === 'percentage';
    }

    function normalizeSubheaderStyleName(raw) {
        var t = compactToken(raw);
        if (!t || t === 'matchtile' || t.indexOf('match') === 0) {
            return 'matchtile';
        }
        if (t === 'darkblue' || t.indexOf('darkblue') === 0) {
            return 'darkblue';
        }
        if (t === 'overlay' || t.indexOf('overlay') === 0) {
            return 'overlay';
        }
        return 'matchtile';
    }

    function sanitizeHexColor(raw, fallback) {
        var s = String(raw == null ? '' : raw).trim();
        return /^#[0-9A-Fa-f]{6}$/.test(s) ? s : fallback;
    }

    function clamp(n, lo, hi) {
        return Math.max(lo, Math.min(hi, n));
    }

    function dataSparkBounds(values) {
        var lo = Infinity;
        var hi = -Infinity;
        var i;
        for (i = 0; i < values.length; i += 1) {
            var v = Number(values[i]);
            if (!isFinite(v)) {
                continue;
            }
            if (v < lo) {
                lo = v;
            }
            if (v > hi) {
                hi = v;
            }
        }
        if (!isFinite(lo) || !isFinite(hi)) {
            return { min: 0, max: 100 };
        }
        if (lo === hi) {
            hi = lo + 1;
        }
        return { min: lo, max: hi };
    }

    /**
     * Resolve spark Y scale. Auto when sparkAuto is on, or when min/max are blank
     * (formatter labels say "blank if auto" — blank + Auto Off previously forced 0–100
     * and flattened any series outside that range into a straight line).
     */
    function sparkBounds(minIn, maxIn, values, sparkAuto) {
        var lo2 = parseFloat(minIn, 10);
        var hi2 = parseFloat(maxIn, 10);
        var hasManual = isFinite(lo2) || isFinite(hi2);
        if (truthy(sparkAuto) || !hasManual) {
            return dataSparkBounds(values);
        }
        if (!isFinite(lo2)) {
            lo2 = 0;
        }
        if (!isFinite(hi2)) {
            hi2 = 100;
        }
        if (lo2 > hi2) {
            var t = lo2;
            lo2 = hi2;
            hi2 = t;
        }
        if (hi2 <= lo2) {
            hi2 = lo2 + 1;
        }
        return { min: lo2, max: hi2 };
    }

    function trendDelta(values) {
        if (!values || !values.length) {
            return NaN;
        }
        var len = values.length;
        var last = Number(values[len - 1]);
        var prev = len > 1 ? Number(values[len - 2]) : last;
        if (!isFinite(last) || !isFinite(prev)) {
            return NaN;
        }
        return last - prev;
    }

    function trendBackground(delta, upColor, downColor, invertTrend) {
        var downIsGood = truthy(invertTrend);
        if (!isFinite(delta)) {
            return upColor;
        }
        if (delta < 0) {
            return downIsGood ? upColor : downColor;
        }
        return downIsGood ? downColor : upColor;
    }

    /** Classic Single Value rangeValues + rangeColors → background for a numeric value. */
    function rangeBackgroundForValue(value, rangeValuesRaw, rangeColorsRaw, fallback) {
        var bounds = String(rangeValuesRaw == null ? '' : rangeValuesRaw)
            .split(',')
            .map(function (part) {
                return parseFloat(String(part).trim(), 10);
            })
            .filter(function (n) {
                return isFinite(n);
            })
            .sort(function (a, b) {
                return a - b;
            });
        var colors = String(rangeColorsRaw == null ? '' : rangeColorsRaw)
            .split(',')
            .map(function (part) {
                return String(part).trim().replace(/^0x/i, '#');
            })
            .filter(function (c) {
                return !!c;
            });
        if (!bounds.length || !colors.length || !isFinite(value)) {
            return fallback;
        }
        var idx = 0;
        var i;
        for (i = 0; i < bounds.length; i += 1) {
            if (value >= bounds[i]) {
                idx = Math.min(i, colors.length - 1);
            }
        }
        return sanitizeHexColor(colors[idx], fallback);
    }

    function applyTrendHostStyle(el, bg, textColor) {
        if (!el) {
            return;
        }
        el.style.position = 'relative';
        el.style.backgroundColor = bg;
        el.style.setProperty('background', bg, 'important');
        el.style.color = textColor;
        el.style.overflow = 'hidden';
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.minHeight = '100%';
        el.style.boxSizing = 'border-box';
        el.style.pointerEvents = 'auto';
    }

    function resolveSubheaderStyle(config, viz) {
        var styleFound = findConfigValue(config, 'subheaderStyle', viz);
        if (styleFound.found && String(styleFound.value).trim()) {
            return normalizeSubheaderStyleName(styleFound.value);
        }
        return truthy(optOrFromConfig(config, viz, 'subheaderMatchTile', 'true')) ? 'matchtile' : 'overlay';
    }

    function optOrFromConfig(config, viz, prop, builtInDefault) {
        var found = findConfigValue(config, prop, viz);
        if (!found.found) {
            return builtInDefault;
        }
        var raw = found.value;
        if (typeof raw === 'string' && raw.trim() === '') {
            return builtInDefault;
        }
        return raw;
    }

    function applySubheaderStyle(head, subheaderStyle, bg, goodColor, textColor) {
        if (!head) {
            return;
        }
        var style = normalizeSubheaderStyleName(subheaderStyle);
        var bgColor = 'rgba(0,0,0,0.52)';
        if (style === 'matchtile') {
            bgColor = bg;
            head.className += ' bgdhamp-sparkline-value-viz__header--matchTile';
        } else if (style === 'darkblue') {
            bgColor = goodColor;
            head.className += ' bgdhamp-sparkline-value-viz__header--darkBlue';
        } else {
            head.className += ' bgdhamp-sparkline-value-viz__header--overlay';
        }
        head.style.setProperty('background', bgColor, 'important');
        head.style.setProperty('color', textColor, 'important');
        head.style.flex = '0 0 ' + SUBHEADER_HEIGHT_PX + 'px';
        head.style.height = SUBHEADER_HEIGHT_PX + 'px';
        head.style.minHeight = SUBHEADER_HEIGHT_PX + 'px';
        head.style.maxHeight = SUBHEADER_HEIGHT_PX + 'px';
        head.style.boxSizing = 'border-box';
        head.style.display = 'flex';
        head.style.alignItems = 'center';
        head.style.overflow = 'hidden';
        head.style.padding = '0 10px';
        head.style.fontSize = '12px';
        head.style.fontWeight = '500';
        head.style.width = '100%';
        head.style.boxSizing = 'border-box';
    }

    function measureSparkWrap(sparkWrap) {
        var rect = sparkWrap.getBoundingClientRect();
        return {
            w: Math.max(1, Math.round(rect.width) || sparkWrap.clientWidth || 360),
            h: Math.max(1, Math.round(rect.height) || sparkWrap.clientHeight || SPARK_STRIP_HEIGHT_PX),
        };
    }

    function sizeSparkSvg(svg, w, h) {
        svg.setAttribute('preserveAspectRatio', 'none');
        svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
        svg.setAttribute('width', String(w));
        svg.setAttribute('height', String(h));
        svg.style.width = w + 'px';
        svg.style.height = h + 'px';
        svg.style.overflow = 'visible';
        svg.style.display = 'block';
    }

    function normalizeName(name) {
        return String(name == null ? '' : name)
            .trim()
            .toLowerCase();
    }

    function findFieldIndex(fields, requested) {
        var wanted = normalizeName(requested);
        var i;
        if (!wanted) {
            return -1;
        }
        for (i = 0; i < fields.length; i += 1) {
            if (normalizeName(fieldName(fields, i)) === wanted) {
                return i;
            }
        }
        return -1;
    }

    function columnHasNumber(rawData, columnIndex) {
        var col = (rawData && rawData.columns && rawData.columns[columnIndex]) || [];
        var r;
        for (r = 0; r < col.length; r += 1) {
            if (isFinite(parseNum(col[r]))) {
                return true;
            }
        }
        return false;
    }

    function isSkippedValueField(name) {
        var n = normalizeName(name);
        if (!n || SKIP_VALUE_FIELDS[n] || n.charAt(0) === '_') {
            return true;
        }
        if (/^text[123]$/.test(n) || /^text[123]_/.test(n) || /^urls?\d*$/.test(n)) {
            return true;
        }
        return false;
    }

    function pickNumericColumnIndex(rawData) {
        var fields = fieldsList(rawData);
        if (!rawData || !rawData.columns || !fields.length) {
            return -1;
        }
        var h;
        var c;
        var best = -1;
        for (h = 0; h < VALUE_FIELD_HINTS.length; h += 1) {
            var hinted = findFieldIndex(fields, VALUE_FIELD_HINTS[h]);
            if (
                hinted >= 0 &&
                !isSkippedValueField(fieldName(fields, hinted)) &&
                columnHasNumber(rawData, hinted)
            ) {
                return hinted;
            }
        }
        for (c = 0; c < rawData.columns.length; c += 1) {
            if (isSkippedValueField(fieldName(fields, c))) {
                continue;
            }
            if (columnHasNumber(rawData, c)) {
                best = c;
            }
        }
        return best;
    }

    function resolveValueColumnIndex(rawData, valueField) {
        var fields = fieldsList(rawData);
        var wanted = normalizeName(valueField);
        if (wanted && wanted !== 'auto') {
            var explicit = findFieldIndex(fields, valueField);
            if (explicit >= 0 && fieldName(fields, explicit) !== '_time') {
                return explicit;
            }
            return -1;
        }
        return pickNumericColumnIndex(rawData);
    }

    /**
     * Build KPI series from column-major results.
     * Soft-fails (empty values) when no usable metric — Single Value–compatible.
     */
    function buildSeriesFromRaw(rawData, valueField) {
        if (!rawData || !rawData.columns || rawData.columns.length === 0) {
            return { values: [], times: [], fieldName: '', stringFields: {} };
        }
        var fields = fieldsList(rawData);
        var idx = resolveValueColumnIndex(rawData, valueField);
        if (idx < 0) {
            return { values: [], times: [], fieldName: '', stringFields: {} };
        }
        var series = reorderSeriesByTime(rawData, idx);
        return {
            values: series.values || [],
            times: series.times || [],
            fieldName: fieldName(fields, idx),
            stringFields: reorderAllStringFieldsByTime(rawData, idx),
        };
    }

    function getTimeSortedValuePairs(rawData, valueIdx) {
        var col = rawData.columns[valueIdx] || [];
        if (!col.length) {
            return [];
        }
        var n = col.length;
        var tIdx = findTimeColumnIndex(rawData);
        var pairs = [];
        var r;
        if (tIdx < 0 || !rawData.columns[tIdx] || rawData.columns[tIdx].length !== n) {
            for (r = 0; r < n; r += 1) {
                var v0 = parseNum(col[r]);
                if (isFinite(v0)) {
                    pairs.push({ v: v0, timeRaw: null, rowIdx: r });
                }
            }
            return pairs;
        }
        var timeCol = rawData.columns[tIdx];
        for (r = 0; r < n; r += 1) {
            var v = parseNum(col[r]);
            if (!isFinite(v)) {
                continue;
            }
            pairs.push({
                t: timeSortKey(rawData, tIdx, r),
                v: v,
                timeRaw: cellValue(timeCol[r]),
                rowIdx: r,
            });
        }
        pairs.sort(function (a, b) {
            if (a.t !== b.t) {
                return a.t - b.t;
            }
            return a.rowIdx - b.rowIdx;
        });
        return pairs;
    }

    function reorderSeriesByTime(rawData, valueIdx) {
        var pairs = getTimeSortedValuePairs(rawData, valueIdx);
        var values = [];
        var times = [];
        var r;
        for (r = 0; r < pairs.length; r += 1) {
            values.push(pairs[r].v);
            times.push(pairs[r].timeRaw);
        }
        return { values: values, times: times };
    }

    function pickColumnIndexByName(rawData, name) {
        var fields = fieldsList(rawData);
        var i;
        for (i = 0; i < fields.length; i += 1) {
            if (fieldName(fields, i) === name) {
                return i;
            }
        }
        return -1;
    }

    function reorderStringColumnByTime(rawData, strIdx, valueIdx) {
        var pairs = getTimeSortedValuePairs(rawData, valueIdx);
        var strCol = rawData.columns[strIdx] || [];
        var out = [];
        var r;
        for (r = 0; r < pairs.length; r += 1) {
            var cell = strCol[pairs[r].rowIdx];
            var raw = cellValue(cell);
            out.push(raw == null ? '' : String(raw).trim());
        }
        return out;
    }

    function reorderAllStringFieldsByTime(rawData, valueIdx) {
        var fields = fieldsList(rawData);
        var out = {};
        var c;
        if (!rawData || !rawData.columns) {
            return out;
        }
        for (c = 0; c < rawData.columns.length; c += 1) {
            var fn = fieldName(fields, c);
            if (!fn || fn === '_time' || c === valueIdx) {
                continue;
            }
            out[fn] = reorderStringColumnByTime(rawData, c, valueIdx);
        }
        return out;
    }

    function drawSparkLabelAtIndex(
        svg,
        values,
        pi,
        labelText,
        w,
        h,
        padL,
        padR,
        padT,
        padB,
        vmin,
        vmax,
        sparkStroke
    ) {
        var xy = sparkXY(values, pi, w, h, padL, padR, padT, padB, vmin, vmax);
        var mark = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        mark.setAttribute('cx', xy.x.toFixed(1));
        mark.setAttribute('cy', xy.y.toFixed(1));
        mark.setAttribute('r', '3');
        mark.setAttribute('fill', sparkStroke);
        svg.appendChild(mark);
        var lbl = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        lbl.setAttribute('x', xy.x.toFixed(1));
        lbl.setAttribute('y', String(Math.max(10, xy.y - 7)));
        lbl.setAttribute('fill', 'rgba(255,255,255,0.9)');
        lbl.setAttribute('font-size', '9');
        lbl.setAttribute('font-weight', '700');
        if (xy.x <= padL + 2) {
            lbl.setAttribute('text-anchor', 'start');
            lbl.setAttribute('dx', '2');
        } else if (xy.x >= w - padR - 2) {
            lbl.setAttribute('text-anchor', 'end');
            lbl.setAttribute('dx', '-2');
        } else {
            lbl.setAttribute('text-anchor', 'middle');
        }
        lbl.textContent = labelText;
        svg.appendChild(lbl);
    }

    function normalizeTimes(rawTimes, len) {
        var times = Array.isArray(rawTimes) ? rawTimes.slice(0, len) : [];
        var ms = [];
        var ok = 0;
        var i;
        for (i = 0; i < len; i += 1) {
            var t = times[i];
            if (typeof t === 'string') {
                var parsed = Date.parse(t);
                if (isFinite(parsed)) {
                    ms.push(parsed);
                    ok += 1;
                    continue;
                }
            }
            if (typeof t === 'number' && isFinite(t)) {
                if (t > 31536000000) {
                    ms.push(t);
                } else if (t > 31536000) {
                    ms.push(t * 1000);
                } else {
                    ms.push(null);
                }
                if (ms[i] != null) {
                    ok += 1;
                }
                continue;
            }
            ms.push(null);
        }
        return { ms: ms, timeLike: ok >= Math.max(2, Math.floor(len * 0.5)) };
    }

    function formatHoverTime(times, norm, idx) {
        if (norm.timeLike && norm.ms[idx] != null) {
            return new Date(norm.ms[idx]).toLocaleString(undefined, {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
            });
        }
        if (times[idx] == null) {
            return '';
        }
        return String(times[idx]);
    }

    function parseSparkPointLabels(raw) {
        var map = {};
        var s = String(raw == null ? '' : raw).trim();
        if (!s) {
            return map;
        }
        var parts = s.split(/[,;]+/);
        var i;
        for (i = 0; i < parts.length; i += 1) {
            var p = parts[i].trim();
            if (!p) {
                continue;
            }
            var colon = p.indexOf(':');
            if (colon < 0) {
                continue;
            }
            var idx = parseInt(p.slice(0, colon), 10);
            var label = p.slice(colon + 1).trim();
            if (isFinite(idx) && idx >= 0 && label) {
                map[idx] = label;
            }
        }
        return map;
    }

    function sparkPath(values, w, h, padL, padR, padT, padB, vmin, vmax) {
        var iw = Math.max(1, w - padL - padR);
        var ih = Math.max(1, h - padT - padB);
        var len = values.length;
        if (len < 2) {
            return '';
        }
        var xStep = iw / (len - 1);
        var parts = [];
        var i;
        for (i = 0; i < len; i += 1) {
            var val = Number(values[i]);
            var ratio = (val - vmin) / (vmax - vmin);
            ratio = Math.max(0, Math.min(1, ratio));
            var x = padL + i * xStep;
            var y = padT + ih - ratio * ih;
            parts.push((i === 0 ? 'M' : 'L') + x.toFixed(1) + ' ' + y.toFixed(1));
        }
        return parts.join(' ');
    }

    function sparkAreaPath(values, w, h, padL, padR, padT, padB, vmin, vmax) {
        var line = sparkPath(values, w, h, padL, padR, padT, padB, vmin, vmax);
        if (!line) {
            return '';
        }
        var len = values.length;
        var iw = Math.max(1, w - padL - padR);
        var xStep = iw / (len - 1);
        var lastX = padL + (len - 1) * xStep;
        // Flush to the SVG bottom (ignore padB) so the wash meets the tile edge.
        var baselineY = h;
        return (
            line +
            ' L' +
            lastX.toFixed(1) +
            ' ' +
            baselineY.toFixed(1) +
            ' L' +
            padL.toFixed(1) +
            ' ' +
            baselineY.toFixed(1) +
            ' Z'
        );
    }

    /** Single Value–style area: flat wash of area color (default spark stroke white) at 20%. */
    function resolveAreaFill(areaColor) {
        return { color: areaColor || '#FFFFFF', opacity: '0.2' };
    }

    function applyVizHeight(el, heightPx) {
        if (!el || !isFinite(heightPx)) {
            return;
        }
        var h = Math.max(80, Math.min(800, Math.round(heightPx)));
        var px = h + 'px';
        var node = el;
        var hops = 0;
        while (node && hops < 14) {
            node.style.height = px;
            node.style.minHeight = px;
            var cls = String(node.className || '');
            if (cls.indexOf('dashboard-element') !== -1) {
                break;
            }
            node = node.parentElement;
            hops += 1;
        }
    }

    function appendSparkAreaFill(svg, areaD, fillColor, fillOpacity) {
        if (!areaD) {
            return;
        }
        var area = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        area.setAttribute('class', 'bgdhamp-sparkline-value-viz__sparkArea');
        area.setAttribute('d', areaD);
        area.setAttribute('fill', fillColor);
        area.setAttribute('fill-opacity', String(fillOpacity));
        area.setAttribute('stroke', 'none');
        area.style.fill = fillColor;
        area.style.fillOpacity = String(fillOpacity);
        svg.appendChild(area);
    }

    function sparkXY(values, idx, w, h, padL, padR, padT, padB, vmin, vmax) {
        var len = values.length;
        var iw = Math.max(1, w - padL - padR);
        var ih = Math.max(1, h - padT - padB);
        var xStep = len > 1 ? iw / (len - 1) : 0;
        var val = Number(values[idx]);
        var ratio = (val - vmin) / (vmax - vmin);
        ratio = Math.max(0, Math.min(1, ratio));
        return {
            x: padL + idx * xStep,
            y: padT + ih - ratio * ih,
            xStep: xStep,
        };
    }

    function sparkIndexFromPointer(clientX, sparkWrap, padL, padR, w, n) {
        var rect = sparkWrap.getBoundingClientRect();
        if (rect.width <= 0 || n < 2) {
            return null;
        }
        var relX = (clientX - rect.left) / rect.width;
        var xSvg = relX * w;
        var iw = w - padL - padR;
        var idx = Math.round((xSvg - padL) / (iw / (n - 1)));
        return clamp(idx, 0, n - 1);
    }

    function yFromValue(val, h, padT, padB, vmin, vmax) {
        var ih = Math.max(1, h - padT - padB);
        var ratio = (val - vmin) / (vmax - vmin);
        ratio = Math.max(0, Math.min(1, ratio));
        return padT + ih - ratio * ih;
    }

    function formatMajor(value, precision, unit) {
        if (!isFinite(value)) {
            return '—';
        }
        var p = parseInt(precision, 10);
        if (!isFinite(p) || p < 0) {
            p = 2;
        }
        return value.toLocaleString(undefined, { maximumFractionDigits: p, minimumFractionDigits: 0 }) + unit;
    }

    function formatDelta(delta, last, mode, precision) {
        if (!isFinite(delta)) {
            return '—';
        }
        var p = parseInt(precision, 10);
        if (!isFinite(p) || p < 0) {
            p = 2;
        }
        var arrow = delta >= 0 ? '\u25b2 ' : '\u25bc ';
        if (isPercentDelta(mode) && isFinite(last) && last !== 0) {
            var pct = (delta / Math.abs(last)) * 100;
            return arrow + pct.toLocaleString(undefined, { maximumFractionDigits: p }) + '%';
        }
        return arrow + delta.toLocaleString(undefined, { maximumFractionDigits: p });
    }

    function formatHoverValue(v, precision, unit, prefix) {
        if (!isFinite(v)) {
            return '—';
        }
        var p = parseInt(precision, 10);
        if (!isFinite(p) || p < 0) {
            p = 2;
        }
        var core =
            v.toLocaleString(undefined, { maximumFractionDigits: p, minimumFractionDigits: 0 }) +
            String(unit || '');
        var pre = String(prefix || '').trim();
        return pre ? pre + ' ' + core : core;
    }

    function clearSparkHover(svg, tooltip, hoverAnnEl) {
        if (svg) {
            var old = svg.querySelector('.bgdhamp-sparkline-value-viz__hover');
            if (old && old.parentNode) {
                old.parentNode.removeChild(old);
            }
        }
        if (tooltip) {
            tooltip.style.display = 'none';
        }
        if (hoverAnnEl) {
            hoverAnnEl.style.display = 'none';
            hoverAnnEl.textContent = '';
        }
    }

    function updateSparkHover(svg, tooltip, ownerDoc, opts) {
        clearSparkHover(svg, tooltip, opts.hoverAnnEl);
        var g = ownerDoc.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('class', 'bgdhamp-sparkline-value-viz__hover');
        g.setAttribute('pointer-events', 'none');

        var line = ownerDoc.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', opts.hx.toFixed(1));
        line.setAttribute('x2', opts.hx.toFixed(1));
        line.setAttribute('y1', String(opts.padT));
        line.setAttribute('y2', String(opts.h - opts.padB));
        line.setAttribute('stroke', 'rgba(255,255,255,0.55)');
        line.setAttribute('stroke-width', '1');
        g.appendChild(line);

        var dot = ownerDoc.createElementNS('http://www.w3.org/2000/svg', 'circle');
        dot.setAttribute('cx', opts.hx.toFixed(1));
        dot.setAttribute('cy', opts.hy.toFixed(1));
        dot.setAttribute('r', '4');
        dot.setAttribute('fill', opts.stroke);
        dot.setAttribute('stroke', 'rgba(0,0,0,0.35)');
        dot.setAttribute('stroke-width', '1');
        g.appendChild(dot);
        svg.appendChild(g);

        var valueLabel = formatHoverValue(opts.v, opts.precision, opts.unit, opts.tooltipPrefix);
        var timeLabel = opts.timeLabel || '';
        var annotationLabel = opts.annotationLabel || '';
        var pointLabel = opts.pointLabel || '';
        var lines = [];
        if (annotationLabel) {
            lines.push(annotationLabel);
        }
        if (pointLabel && pointLabel !== annotationLabel) {
            lines.push(pointLabel);
        }
        lines.push(valueLabel);
        if (timeLabel) {
            lines.push(timeLabel);
        }

        tooltip.textContent = '';
        var valueLineIdx = lines.indexOf(valueLabel);
        var i;
        for (i = 0; i < lines.length; i += 1) {
            var row = ownerDoc.createElement('div');
            row.className =
                i < valueLineIdx
                    ? 'bgdhamp-sparkline-value-viz__tooltipPoint'
                    : i === valueLineIdx
                      ? 'bgdhamp-sparkline-value-viz__tooltipValue'
                      : 'bgdhamp-sparkline-value-viz__tooltipTime';
            row.textContent = lines[i];
            tooltip.appendChild(row);
        }

        tooltip.style.display = 'block';
        tooltip.style.position = 'fixed';
        tooltip.style.zIndex = '2147483646';
        tooltip.style.left = opts.clientX + 'px';
        tooltip.style.top = opts.clientY + 'px';
        tooltip.style.transform = 'translate(-50%, calc(-100% - 8px))';
        var bodyEl = ownerDoc.body || ownerDoc.documentElement;
        if (bodyEl && tooltip.parentNode !== bodyEl) {
            bodyEl.appendChild(tooltip);
        }

        if (opts.showHoverAnnotation && opts.hoverAnnEl) {
            opts.hoverAnnEl.textContent = lines.join(' \u2014 ');
            opts.hoverAnnEl.style.display = 'block';
        }
    }

    var KpiSparklineViz = SplunkVisualizationBase.extend({
        getInitialDataParams: function () {
            return {
                outputMode: SplunkVisualizationBase.COLUMN_MAJOR_OUTPUT_MODE,
                count: 5000,
            };
        },

        formatData: function (rawData) {
            var safe = rawData && rawData.columns ? rawData : { columns: [], fields: [] };
            var series = buildSeriesFromRaw(safe, 'auto');
            return {
                rawData: safe,
                values: series.values,
                times: series.times,
                fieldName: series.fieldName,
                stringFields: series.stringFields,
            };
        },

        updateView: function (data, config) {
            var viz = this;
            function opt(prop, defaultVal) {
                return readConfig(config, prop, defaultVal, viz);
            }
            /** When Splunk has no key yet (cached panel), use formatter demo defaults. */
            function optOr(prop, builtInDefault) {
                var found = findConfigValue(config, prop, viz);
                if (!found.found) {
                    return builtInDefault;
                }
                var raw = found.value;
                if (typeof raw === 'string' && raw.trim() === '') {
                    return builtInDefault;
                }
                return raw;
            }
            /** Label/badge: missing key → demo default; explicit blank → hide (empty string). */
            function optLabel(prop, builtInDefault) {
                var found = findConfigValue(config, prop, viz);
                if (!found.found) {
                    return builtInDefault;
                }
                var raw = found.value;
                if (typeof raw === 'string') {
                    return raw.trim();
                }
                return String(raw).trim();
            }

            function isInlineHeadline(raw) {
                var t = compactToken(raw);
                return (
                    t === 'inline' ||
                    t === 'sidebyside' ||
                    t === 'side' ||
                    t === 'row' ||
                    t === 'horizontal'
                );
            }

            function isLabelRight(raw) {
                var s = String(raw == null ? '' : raw)
                    .trim()
                    .toLowerCase()
                    .replace(/[_-]+/g, ' ');
                return s === 'right' || s === 'right of value' || s === 'rightofvalue';
            }

            if (typeof this._docHoverCleanup === 'function') {
                this._docHoverCleanup();
                this._docHoverCleanup = null;
            }
            if (this._hoverTooltipEl && this._hoverTooltipEl.parentNode) {
                this._hoverTooltipEl.parentNode.removeChild(this._hoverTooltipEl);
                this._hoverTooltipEl = null;
            }
            if (typeof this._infoCleanup === 'function') {
                this._infoCleanup();
                this._infoCleanup = null;
            }

            this.el.innerHTML = '';
            var valueFieldCustom = String(opt('valueFieldCustom', '') || '').trim();
            var valueField = valueFieldCustom
                ? valueFieldCustom
                : String(opt('valueField', 'auto') || 'auto').trim() || 'auto';
            var rawData = data && data.rawData ? data.rawData : null;
            var series =
                rawData && rawData.columns
                    ? buildSeriesFromRaw(rawData, valueField)
                    : {
                          values: (data && data.values) || [],
                          times: (data && data.times) || [],
                          fieldName: (data && data.fieldName) || '',
                          stringFields: (data && data.stringFields) || {},
                      };
            var values = series.values || [];
            var times = series.times || [];
            var emptyText = String(opt('emptyText', 'No numeric results to display.') || '');

            if (values.length === 0) {
                var emptyBg = sanitizeHexColor(opt('background', '#0B1F3B'), '#0B1F3B');
                var emptyFg = sanitizeHexColor(opt('textColor', '#FFFFFF'), '#FFFFFF');
                applyTrendHostStyle(this.el, emptyBg, emptyFg);
                var empty = document.createElement('div');
                empty.className = 'bgdhamp-sparkline-value-viz__err';
                var emptyMsg = emptyText;
                if (
                    (!emptyMsg || emptyMsg === 'No numeric results to display.') &&
                    valueField !== 'auto'
                ) {
                    emptyMsg = 'No results for value field "' + valueField + '".';
                }
                empty.textContent = emptyMsg;
                empty.style.padding = '12px';
                empty.style.fontSize = '12px';
                empty.style.color = emptyFg;
                this.el.appendChild(empty);
                return;
            }

            var sparkAuto = opt('sparkAuto', 'true');
            var sparkMinRaw = opt('sparkMin', '');
            var sparkMaxRaw = opt('sparkMax', '');
            var scale = sparkBounds(sparkMinRaw, sparkMaxRaw, values, sparkAuto);
            var goodColor = sanitizeHexColor(opt('goodColor', '#01417F'), '#01417F');
            var badColor = sanitizeHexColor(opt('badColor', '#DFA611'), '#DFA611');
            var invertTrend = opt('invertTrend', 'false');
            var textColor = sanitizeHexColor(opt('textColor', '#FFFFFF'), '#FFFFFF');
            var sparkStroke = sanitizeHexColor(opt('sparkStroke', '#FFFFFF'), '#FFFFFF');
            var sparkStrokeWidth = parseFloat(opt('sparkStrokeWidth', '2'), 10);
            if (!isFinite(sparkStrokeWidth) || sparkStrokeWidth <= 0) {
                sparkStrokeWidth = 2;
            }
            var sparkAreaColor = sanitizeHexColor(optOr('sparkAreaColor', sparkStroke), sparkStroke);
            var sparkHeightPx = parseFloat(optOr('sparkHeight', String(SPARK_STRIP_HEIGHT_PX)), 10);
            if (!isFinite(sparkHeightPx) || sparkHeightPx <= 0) {
                sparkHeightPx = SPARK_STRIP_HEIGHT_PX;
            }
            sparkHeightPx = Math.max(12, Math.min(240, sparkHeightPx));
            var vizHeightPx = parseFloat(optOr('vizHeight', String(PANEL_DEFAULT_HEIGHT_PX)), 10);
            if (!isFinite(vizHeightPx) || vizHeightPx <= 0) {
                vizHeightPx = PANEL_DEFAULT_HEIGHT_PX;
            }
            vizHeightPx = Math.max(80, Math.min(800, vizHeightPx));
            var unit = String(opt('unit', '') || '');
            var underLabel = String(opt('underLabel', '') || '').trim();
            var subheader = underLabel || String(opt('subheader', '') || '');
            var precision = opt('precision', '2');
            var showTrendIndicator = truthy(optOr('showTrendIndicator', 'true'));
            var showDelta =
                showTrendIndicator && truthy(opt('showDelta', 'true')) && values.length >= 2;
            var deltaMode = String(opt('deltaMode', 'absolute') || 'absolute');
            var colorBy = String(opt('colorBy', 'trend') || 'trend')
                .trim()
                .toLowerCase();
            var colorMode = String(opt('colorMode', 'block') || 'block')
                .trim()
                .toLowerCase();
            var rangeValuesRaw = opt('rangeValues', '');
            var rangeColorsRaw = opt('rangeColors', '');
            var showSparkline = truthy(opt('showSparkline', 'true')) && values.length >= 2;
            var showSparkArea = truthy(optOr('showSparkArea', 'true'));
            var textCells = truthy(optOr('showTextRow', 'true')) ? collectTextCells(series, opt) : [];
            var textRowPx = textCells.length ? TEXT_ROW_HEIGHT_PX : 0;
            var showInfo = truthy(optOr('showInfo', 'false'));
            var infoText = '';
            if (showInfo) {
                infoText = String(opt('infoText', '') || '').trim();
                if (!infoText) {
                    infoText = lastStringValue(series, String(optOr('infoField', 'info') || '').trim());
                }
                showInfo = !!infoText;
            }
            // Cap spark so KPI + delta always keep a readable band above it.
            if (showSparkline) {
                var reservedAboveSpark =
                    (subheader ? SUBHEADER_HEIGHT_PX : 0) + textRowPx + HEADLINE_MIN_PX + 12;
                var maxSparkForTile = Math.max(12, vizHeightPx - reservedAboveSpark);
                if (sparkHeightPx > maxSparkForTile) {
                    sparkHeightPx = maxSparkForTile;
                }
            }
            var showTarget = truthy(opt('showTarget', 'false'));
            var target = parseFloat(opt('target', '50'), 10);
            var showThresholdBand = truthy(opt('showThresholdBand', 'false'));
            var thresholdMin = parseFloat(opt('thresholdMin', '20'), 10);
            var thresholdMax = parseFloat(opt('thresholdMax', '80'), 10);
            var showHover = truthy(opt('showHover', 'true'));
            var showHoverAnnotation = truthy(optOr('showHoverAnnotation', 'true'));
            // In-chart hover text sits above the spark; skip it when that band is too thin
            // (tooltip still shows). Fixes overlap at vizHeight=140 / sparkHeight=70.
            var bodyBudgetPx = vizHeightPx - (subheader ? SUBHEADER_HEIGHT_PX : 0) - textRowPx;
            var spaceAboveSparkPx = showSparkline
                ? bodyBudgetPx - sparkHeightPx - 12
                : bodyBudgetPx;
            if (showHoverAnnotation && spaceAboveSparkPx < HOVER_ANN_MIN_GAP_PX) {
                showHoverAnnotation = false;
            }
            var tooltipPrefix = String(optOr('tooltipPrefix', '') || '');
            var majorLabel = optLabel('majorLabel', DEMO_LABELS.majorLabel);
            var deltaLabel = optLabel('deltaLabel', DEMO_LABELS.deltaLabel);
            var badgeText = optLabel('badgeText', DEMO_LABELS.badgeText);
            var sparkPointLabels = parseSparkPointLabels(
                optLabel('sparkPointLabels', DEMO_LABELS.sparkPointLabels)
            );
            var showPointLabels = truthy(optOr('showPointLabels', 'false'));
            var headlineLayoutRaw = opt('headlineLayout', 'stacked');
            var majorFontSizePx = parseFloat(opt('majorFontSize', '26'), 10);
            if (!isFinite(majorFontSizePx) || majorFontSizePx <= 0) {
                majorFontSizePx = 26;
            }
            majorFontSizePx = Math.max(10, Math.min(96, majorFontSizePx));
            var labelPositionRaw = opt('labelPosition', 'above');
            var labelPosition = isLabelRight(labelPositionRaw) ? 'right' : 'above';
            var headlineIsInline = isInlineHeadline(headlineLayoutRaw);
            var sparkEdgeToEdge = truthy(opt('sparkEdgeToEdge', 'false'));
            var subheaderStyle = resolveSubheaderStyle(config, viz);
            var annotationField = String(opt('annotationField', 'annotation') || '').trim();
            var showAnnotationHover = truthy(optOr('showAnnotationHover', 'true'));
            var showAnnotationLabels = truthy(optOr('showAnnotationLabels', 'false'));
            var annotations = [];
            if (annotationField && series.stringFields && series.stringFields[annotationField]) {
                annotations = series.stringFields[annotationField];
            }
            while (annotations.length < values.length) {
                annotations.push('');
            }

            var delta = trendDelta(values);
            var last = values[values.length - 1];
            var bg = trendBackground(delta, goodColor, badColor, invertTrend);
            if (colorBy === 'value') {
                bg = rangeBackgroundForValue(last, rangeValuesRaw, rangeColorsRaw, bg);
            }
            if (colorMode === 'none') {
                bg = sanitizeHexColor(opt('background', '#FFFFFF'), '#FFFFFF');
            }
            applyTrendHostStyle(this.el, bg, textColor);
            applyVizHeight(this.el, vizHeightPx);
            var areaFill = resolveAreaFill(sparkAreaColor);

            var ownerDoc = (this.el && this.el.ownerDocument) || document;
            var norm = normalizeTimes(times, values.length);

            var root = document.createElement('div');
            root.className = 'bgdhamp-sparkline-value-viz';
            root.setAttribute('data-bgdhamp-viz-build', VIZ_BUILD);
            root.setAttribute('data-bgdhamp-headline-layout', headlineIsInline ? 'inline' : 'stacked');
            root.setAttribute('data-bgdhamp-spark-area', showSparkArea ? 'on' : 'off');
            root.setAttribute('data-bgdhamp-frame-subheader', String(SUBHEADER_HEIGHT_PX));
            root.setAttribute('data-ss-frame-body', String(BODY_FRAME_HEIGHT_PX));
            root.setAttribute('data-ss-frame-panel', String(PANEL_DEFAULT_HEIGHT_PX));
            root.style.position = 'relative';
            root.style.backgroundColor = bg;
            root.style.color = textColor;
            root.style.width = '100%';
            root.style.height = '100%';
            root.style.minHeight = '0';
            root.style.boxSizing = 'border-box';
            root.style.display = 'flex';
            root.style.flexDirection = 'column';

            if (badgeText) {
                var badge = document.createElement('div');
                badge.className = 'bgdhamp-sparkline-value-viz__badge';
                badge.textContent = badgeText;
                badge.setAttribute('title', badgeText);
                inlineBadgeStyle(badge);
                if (showInfo) {
                    badge.style.right = 8 + INFO_ICON_SIZE_PX + 8 + 'px';
                }
                if (!subheader && textRowPx) {
                    badge.style.top = textRowPx + 6 + 'px';
                }
                root.appendChild(badge);
            }

            if (subheader) {
                var head = document.createElement('div');
                head.className = 'bgdhamp-sparkline-value-viz__header';
                applySubheaderStyle(head, subheaderStyle, bg, goodColor, textColor);
                head.textContent = subheader;
                if (showInfo) {
                    head.style.paddingRight = 8 + INFO_ICON_SIZE_PX + 8 + 'px';
                }
                root.appendChild(head);
            }

            if (textCells.length) {
                var textRow = ownerDoc.createElement('div');
                textRow.className = 'bgdhamp-sparkline-value-viz__textRow';
                textRow.setAttribute('data-bgdhamp-text-cells', String(textCells.length));
                textRow.style.display = 'flex';
                textRow.style.flexDirection = 'row';
                textRow.style.alignItems = 'stretch';
                textRow.style.width = '100%';
                textRow.style.flex = '0 0 ' + TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.height = TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.minHeight = TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.maxHeight = TEXT_ROW_HEIGHT_PX + 'px';
                textRow.style.boxSizing = 'border-box';
                textRow.style.overflow = 'hidden';
                var textRowColors = resolveTextRowColors(optOr, textColor);
                textRow.setAttribute('data-bgdhamp-text-style', textRowColors.custom ? 'custom' : 'tinted');
                textRow.style.setProperty('background', textRowColors.bg, 'important');
                textRow.style.borderBottom = '1px solid ' + textRowColors.border;
                textRow.style.setProperty('color', textRowColors.fg, 'important');
                if (showInfo && !subheader) {
                    textRow.style.paddingRight = 8 + INFO_ICON_SIZE_PX + 4 + 'px';
                }
                var linkPrefix = splunkPathPrefix(ownerDoc);
                var linkTarget = resolveLinkTarget(optOr('linkTarget', 'newTab'));
                var linkEarliest = String(opt('linkEarliest', '') || '');
                var linkLatest = String(opt('linkLatest', '') || '');
                var ci;
                for (ci = 0; ci < textCells.length; ci += 1) {
                    var tc = textCells[ci];
                    var cellText = tc.label ? tc.label + ': ' + tc.value : tc.value;
                    var href =
                        cellUrl(tc.urlTpl, tc.urlFromField, tc.value, tc.label, linkPrefix) ||
                        buildSearchLink(
                            tc.searchTpl,
                            tc.value,
                            tc.label,
                            linkEarliest,
                            linkLatest,
                            linkPrefix
                        );
                    var cell = href
                        ? makeLinkCell(ownerDoc, href, linkTarget)
                        : ownerDoc.createElement('div');
                    styleTextCell(cell, ci === 0, textRowColors.divider);
                    cell.setAttribute('data-bgdhamp-text-slot', String(tc.slot));
                    cell.textContent = cellText;
                    cell.setAttribute('title', cellText);
                    textRow.appendChild(cell);
                }
                root.appendChild(textRow);
            }

            if (showInfo) {
                var infoTopPx = subheader
                    ? Math.round((SUBHEADER_HEIGHT_PX - INFO_ICON_SIZE_PX) / 2)
                    : textCells.length
                      ? Math.round((TEXT_ROW_HEIGHT_PX - INFO_ICON_SIZE_PX) / 2)
                      : 6;
                var infoIconColor = !subheader && textRowColors ? textRowColors.fg : '';
                this._infoCleanup = mountInfoPopover(viz, root, ownerDoc, infoText, infoTopPx, infoIconColor);
            }

            var body = document.createElement('div');
            body.className = 'bgdhamp-sparkline-value-viz__body';
            body.style.flex = '1 1 auto';
            body.style.position = 'relative';
            body.style.display = 'flex';
            body.style.flexDirection = 'column';
            body.style.alignItems = 'center';
            body.style.justifyContent = 'center';
            // Reserve bottom strip for spark so KPI + delta fit in the 137px body frame.
            body.style.padding = showSparkline
                ? '6px 10px ' + (sparkHeightPx + 6) + 'px'
                : '6px 10px 8px';
            body.style.boxSizing = 'border-box';
            body.style.minHeight = '0';
            body.style.overflow = 'hidden';

            var headlineRow = document.createElement('div');
            headlineRow.className =
                'bgdhamp-sparkline-value-viz__headlineRow bgdhamp-sparkline-value-viz__headlineRow--' +
                (headlineIsInline ? 'inline' : 'stacked');
            applyHeadlineRowLayout(headlineRow, headlineIsInline);

            var major = document.createElement('div');
            major.className = 'bgdhamp-sparkline-value-viz__major';
            shrinkToContent(major);
            var majorVal = document.createElement('div');
            majorVal.className = 'bgdhamp-sparkline-value-viz__majorValue';
            majorVal.textContent = formatMajor(last, precision, unit);
            majorVal.style.fontSize = majorFontSizePx + 'px';
            majorVal.style.fontWeight = '600';
            majorVal.style.lineHeight = '1.05';
            majorVal.style.color = textColor;
            appendIndicatorPair(major, majorVal, majorLabel, textColor, labelPosition);
            headlineRow.appendChild(major);

            if (showDelta) {
                var trend = document.createElement('div');
                trend.className = 'bgdhamp-sparkline-value-viz__trend';
                shrinkToContent(trend);
                var deltaVal = document.createElement('div');
                deltaVal.className = 'bgdhamp-sparkline-value-viz__trendValue';
                deltaVal.textContent = formatDelta(delta, last, deltaMode, precision);
                deltaVal.style.fontSize = '13px';
                deltaVal.style.fontWeight = '600';
                deltaVal.style.color = textColor;
                appendIndicatorPair(trend, deltaVal, deltaLabel, textColor, labelPosition);
                headlineRow.appendChild(trend);
            }

            body.appendChild(headlineRow);
            headlineRow.style.position = 'relative';
            headlineRow.style.zIndex = '3';

            var hoverAnnEl = null;
            if (showHoverAnnotation) {
                hoverAnnEl = ownerDoc.createElement('div');
                hoverAnnEl.className = 'bgdhamp-sparkline-value-viz__hoverAnn';
                hoverAnnEl.setAttribute('aria-hidden', 'true');
                hoverAnnEl.style.position = 'absolute';
                hoverAnnEl.style.left = '10px';
                hoverAnnEl.style.right = '10px';
                hoverAnnEl.style.bottom = showSparkline ? sparkHeightPx + 8 + 'px' : '8px';
                hoverAnnEl.style.display = 'none';
                hoverAnnEl.style.fontSize = '11px';
                hoverAnnEl.style.fontWeight = '500';
                hoverAnnEl.style.textAlign = 'center';
                hoverAnnEl.style.pointerEvents = 'none';
                hoverAnnEl.style.zIndex = '1';
                body.appendChild(hoverAnnEl);
            }

            var padL = sparkEdgeToEdge ? 0 : 28;
            var padR = sparkEdgeToEdge ? 0 : 28;
            var padT = 8;
            var padB = 0;
            var w = 360;
            var h = sparkHeightPx;
            var n = values.length;
            var sparkWrap = null;

            if (showSparkline) {
                sparkWrap = document.createElement('div');
                sparkWrap.className = 'bgdhamp-sparkline-value-viz__spark';
                if (sparkEdgeToEdge) {
                    sparkWrap.className += ' bgdhamp-sparkline-value-viz__spark--edgeToEdge';
                }
                sparkWrap.style.position = 'absolute';
                sparkWrap.style.left = sparkEdgeToEdge ? '0' : '8px';
                sparkWrap.style.right = sparkEdgeToEdge ? '0' : '8px';
                sparkWrap.style.bottom = '0';
                sparkWrap.style.height = sparkHeightPx + 'px';
                sparkWrap.style.overflow = 'visible';
                body.appendChild(sparkWrap);
            }

            root.appendChild(body);
            this.el.appendChild(root);
            this._lastData = {
                rawData: rawData,
                values: values,
                times: times,
                fieldName: series.fieldName,
                stringFields: series.stringFields,
            };
            this._lastConfig = config;

            if (showSparkline && sparkWrap) {
                var paintSpark = function (deferred) {
                    sparkWrap.innerHTML = '';
                    var measured = measureSparkWrap(sparkWrap);
                    if (measured.w < 2 && !deferred) {
                        var rafWin = ownerDoc.defaultView || window;
                        if (rafWin && typeof rafWin.requestAnimationFrame === 'function') {
                            rafWin.requestAnimationFrame(function () {
                                paintSpark(true);
                            });
                        }
                        return;
                    }
                    w = measured.w;
                    h = measured.h;
                    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                    sizeSparkSvg(svg, w, h);

                if (showThresholdBand && isFinite(thresholdMin) && isFinite(thresholdMax)) {
                    var y1 = yFromValue(thresholdMax, h, padT, padB, scale.min, scale.max);
                    var y2 = yFromValue(thresholdMin, h, padT, padB, scale.min, scale.max);
                    var band = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                    band.setAttribute('x', String(padL));
                    band.setAttribute('y', String(Math.min(y1, y2)));
                    band.setAttribute('width', String(w - padL - padR));
                    band.setAttribute('height', String(Math.abs(y2 - y1)));
                    band.setAttribute('fill', 'rgba(0,0,0,0.18)');
                    svg.appendChild(band);
                }

                if (showTarget && isFinite(target)) {
                    var ty = yFromValue(target, h, padT, padB, scale.min, scale.max);
                    var tLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                    tLine.setAttribute('x1', String(padL));
                    tLine.setAttribute('x2', String(w - padR));
                    tLine.setAttribute('y1', String(ty));
                    tLine.setAttribute('y2', String(ty));
                    tLine.setAttribute('stroke', 'rgba(255,255,255,0.55)');
                    tLine.setAttribute('stroke-width', '1');
                    tLine.setAttribute('stroke-dasharray', '4 3');
                    svg.appendChild(tLine);
                }

                var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                var d = sparkPath(values, w, h, padL, padR, padT, padB, scale.min, scale.max);
                if (d && showSparkArea) {
                    appendSparkAreaFill(
                        svg,
                        sparkAreaPath(values, w, h, padL, padR, padT, padB, scale.min, scale.max),
                        areaFill.color,
                        areaFill.opacity
                    );
                }
                if (d) {
                    path.setAttribute('d', d);
                    path.setAttribute('fill', 'none');
                    path.setAttribute('stroke', sparkStroke);
                    path.setAttribute('stroke-width', String(sparkStrokeWidth));
                    path.setAttribute('vector-effect', 'non-scaling-stroke');
                    svg.appendChild(path);
                }

                if (n >= 1) {
                    var effectivePointLabels = {};
                    var pi;
                    if (showPointLabels) {
                        for (pi = 0; pi < n; pi += 1) {
                            if (Object.prototype.hasOwnProperty.call(sparkPointLabels, pi)) {
                                effectivePointLabels[pi] = sparkPointLabels[pi];
                            }
                        }
                    }
                    if (showAnnotationLabels && annotations.length) {
                        for (pi = 0; pi < annotations.length; pi += 1) {
                            if (annotations[pi]) {
                                effectivePointLabels[pi] = annotations[pi];
                            }
                        }
                    }
                    for (pi = 0; pi < n; pi += 1) {
                        if (!Object.prototype.hasOwnProperty.call(effectivePointLabels, pi)) {
                            continue;
                        }
                        drawSparkLabelAtIndex(
                            svg,
                            values,
                            pi,
                            effectivePointLabels[pi],
                            w,
                            h,
                            padL,
                            padR,
                            padT,
                            padB,
                            scale.min,
                            scale.max,
                            sparkStroke
                        );
                    }
                }

                sparkWrap.appendChild(svg);

                var tooltip = ownerDoc.createElement('div');
                tooltip.className = 'bgdhamp-sparkline-value-viz__tooltip';
                tooltip.setAttribute('role', 'status');
                tooltip.style.display = 'none';
                viz._hoverTooltipEl = tooltip;

                if (showHover && n >= 2) {
                    function hitTestSpark(px, py) {
                        var rect = sparkWrap.getBoundingClientRect();
                        return (
                            rect.width > 0 &&
                            rect.height > 0 &&
                            px >= rect.left &&
                            px <= rect.right &&
                            py >= rect.top &&
                            py <= rect.bottom
                        );
                    }

                    var teardown = [];
                    function onDocPointerMove(e) {
                        if (viz._infoOpen || !hitTestSpark(e.clientX, e.clientY)) {
                            clearSparkHover(svg, tooltip, hoverAnnEl);
                            return;
                        }
                        var idx = sparkIndexFromPointer(e.clientX, sparkWrap, padL, padR, w, n);
                        if (idx == null) {
                            clearSparkHover(svg, tooltip, hoverAnnEl);
                            return;
                        }
                        var xy = sparkXY(values, idx, w, h, padL, padR, padT, padB, scale.min, scale.max);
                        var hoverAnnotation =
                            showAnnotationHover && annotations[idx] ? annotations[idx] : '';
                        updateSparkHover(svg, tooltip, ownerDoc, {
                            hx: xy.x,
                            hy: xy.y,
                            h: h,
                            padT: padT,
                            padB: padB,
                            stroke: sparkStroke,
                            v: values[idx],
                            precision: precision,
                            unit: unit,
                            tooltipPrefix: tooltipPrefix,
                            timeLabel: formatHoverTime(times, norm, idx),
                            annotationLabel: hoverAnnotation,
                            pointLabel: sparkPointLabels[idx] || '',
                            clientX: e.clientX,
                            clientY: e.clientY,
                            showHoverAnnotation: showHoverAnnotation,
                            hoverAnnEl: hoverAnnEl,
                        });
                    }
                    teardown.push(function () {
                        ownerDoc.removeEventListener('pointermove', onDocPointerMove, true);
                        ownerDoc.removeEventListener('mousemove', onDocPointerMove, true);
                        if (ownerDoc.defaultView) {
                            ownerDoc.defaultView.removeEventListener('mousemove', onDocPointerMove, true);
                        }
                    });
                    ownerDoc.addEventListener('pointermove', onDocPointerMove, true);
                    ownerDoc.addEventListener('mousemove', onDocPointerMove, true);
                    if (ownerDoc.defaultView) {
                        ownerDoc.defaultView.addEventListener('mousemove', onDocPointerMove, true);
                    }
                    viz._docHoverCleanup = function () {
                        var ti;
                        for (ti = 0; ti < teardown.length; ti += 1) {
                            teardown[ti]();
                        }
                        clearSparkHover(svg, tooltip, hoverAnnEl);
                    };
                }
                };
                paintSpark(false);
            }
        },

        reflow: function () {
            if (this._lastData && this._lastConfig) {
                this.updateView(this._lastData, this._lastConfig);
            }
        },

        remove: function () {
            if (typeof this._docHoverCleanup === 'function') {
                this._docHoverCleanup();
                this._docHoverCleanup = null;
            }
            if (this._hoverTooltipEl && this._hoverTooltipEl.parentNode) {
                this._hoverTooltipEl.parentNode.removeChild(this._hoverTooltipEl);
                this._hoverTooltipEl = null;
            }
            if (typeof this._infoCleanup === 'function') {
                this._infoCleanup();
                this._infoCleanup = null;
            }
            this.el.innerHTML = '';
        },
    });

    KpiSparklineViz.linkHelpers = {
        escapeSplValue: escapeSplValue,
        buildUrlLink: buildUrlLink,
        buildSearchLink: buildSearchLink,
        buildCellLink: buildCellLink,
        lastStringValue: lastStringValue,
        cellLabel: cellLabel,
        cellUrl: cellUrl,
        parseNum: parseNum,
    };
    return KpiSparklineViz;
});
